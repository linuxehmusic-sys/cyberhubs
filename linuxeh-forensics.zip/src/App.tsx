import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, 
  Shield, 
  Activity, 
  Lock, 
  Globe,
  Search,
  MessageSquare,
  User,
  Zap,
  Layout,
  Moon,
  Sun,
  Sparkles,
  Cpu,
  X,
  Users,
  CreditCard,
  Copy
} from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { MatrixBackground } from './components/MatrixBackground';
import { MatrixTerminal } from './components/MatrixTerminal';
import { CyberSecurityHub } from './components/CyberSecurityHub';
import { IntelligenceAgencies } from './components/IntelligenceAgencies';
import { ForensicTools } from './components/ForensicTools';
import { MissionLog } from './components/MissionLog';
import { ContactManager } from './components/ContactManager';

const TypingText: React.FC<{ text: string }> = ({ text }) => {
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayedText((prev) => prev + text.charAt(i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 50);
    return () => clearInterval(interval);
  }, [text]);

  return <span>{displayedText}</span>;
};

export default function App() {
  const [isLocked, setIsLocked] = useState(true);
  const [password, setPassword] = useState('');
  const [isExploiting, setIsExploiting] = useState(false);
  const [status, setStatus] = useState('');
  const [tgUser, setTgUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'INVESTIGATION' | 'CYBER-INFO' | 'TOOLS' | 'PROFILE' | 'CONTACTS'>('INVESTIGATION');
  const [globalLang, setGlobalLang] = useState<'EN' | 'HI'>('EN');
  const [isGlitching, setIsGlitching] = useState(false);
  const [paidAmount, setPaidAmount] = useState('0');
  const [profileName, setProfileName] = useState('HAIDER');
  const [profilePhoto, setProfilePhoto] = useState('https://picsum.photos/seed/smart-haider/400/400');

  useEffect(() => {
    document.body.className = `${globalLang === 'HI' ? 'hindi-mode' : ''}`;
  }, [globalLang]);

  useEffect(() => {
    // @ts-ignore
    if (window.Telegram?.WebApp) {
      // @ts-ignore
      const tg = window.Telegram.WebApp;
      tg.ready();
      tg.expand();
      if (tg.initDataUnsafe?.user) {
        setTgUser(tg.initDataUnsafe.user);
        setProfileName(tg.initDataUnsafe.user.first_name);
        if (tg.initDataUnsafe.user.photo_url) {
          setProfilePhoto(tg.initDataUnsafe.user.photo_url);
        }
      }
    }
  }, []);

  const handleLogout = () => {
    setIsLocked(true);
    setPassword('');
    setIsExploiting(false);
    setStatus('');
  };

  const handleLogin = () => {
    if (password === '25021991' || password === '25021993') {
      setIsExploiting(true);
      setStatus('AUTHENTICATING...');
      
      setTimeout(() => {
        setIsLocked(false);
        setIsExploiting(false);
        if (password === '25021991') setPaidAmount('499');
        if (password === '25021993') setPaidAmount('999');
      }, 1500);
    } else {
      setStatus('INVALID ACCESS CODE');
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const triggerGlitch = () => {
    setIsGlitching(true);
    setTimeout(() => setIsGlitching(false), 1500);
  };

  return (
    <div className={`min-h-screen selection:bg-electric-green selection:text-black ${isGlitching ? 'glitch' : ''} bg-cyber-bg`}>
      <MatrixBackground />
      <div className="scanlines" />
      <div className="fixed top-0 left-0 w-full h-1 z-[100] bg-gradient-to-r from-electric-green via-electric-green to-electric-green opacity-50" />

      <AnimatePresence mode="wait">
        {isLocked ? (
          <motion.div
            key="login-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-sm overflow-hidden"
          >
            <MatrixBackground />
            <div className="absolute inset-0 bg-electric-green/10 pointer-events-none" />
            <div className="scanlines pointer-events-none opacity-50" />
            <div className="noise-overlay" />
            <div className="vignette" />
            
            {/* Page Border Running Effect */}
            <div className="absolute inset-0 pointer-events-none z-[60]">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-electric-green to-transparent animate-[border-top_3s_linear_infinite]" />
              <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-electric-green to-transparent animate-[border-top_3s_linear_infinite_reverse]" />
              <div className="absolute top-0 left-0 w-[2px] h-full bg-gradient-to-b from-transparent via-electric-green to-transparent animate-[border-left_3s_linear_infinite]" />
              <div className="absolute top-0 right-0 w-[2px] h-full bg-gradient-to-b from-transparent via-electric-green to-transparent animate-[border-left_3s_linear_infinite_reverse]" />
            </div>

            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="w-full max-w-[340px] bevel-card p-[2px] bg-gradient-to-br from-electric-green via-electric-green to-electric-green glow-green relative"
            >
              <div className="bg-black/95 backdrop-blur-xl bevel-card overflow-hidden">
                {/* Scanline effect on card */}
                <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(114,255,19,0)_50%,rgba(114,255,19,0.05)_50%),linear-gradient(90deg,rgba(114,255,19,0.02),rgba(114,255,19,0.02))] bg-[length:100%_2px,2px_100%] z-10" />
                
                <div className="p-8 text-center relative z-20">
                  <div className="flex justify-center mb-6">
                    <motion.div 
                      animate={{ 
                        scale: [1, 1.1, 1],
                        filter: ["drop-shadow(0 0 0px rgba(114,255,19,0))", "drop-shadow(0 0 10px rgba(114,255,19,0.5))", "drop-shadow(0 0 0px rgba(114,255,19,0))"]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="p-3 bg-electric-green/10 bevel-card-sm border border-electric-green/30"
                    >
                      <Shield className="w-8 h-8 text-electric-green" />
                    </motion.div>
                  </div>
                  
                  <h1 className="text-xl font-bold text-red mb-1 tracking-widest">
                    <span className="inline-block animate-pulse">SECURE</span> LOGIN
                  </h1>
                  <p className="text-[10px] text-red/40 mb-8 uppercase tracking-[0.4em] font-mono">Authorization Required</p>

                <div className="space-y-5">
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-electric-green/30 group-focus-within:text-electric-green transition-colors" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="ACCESS CODE"
                      className="w-full pl-12 pr-4 py-4 bg-electric-green/5 border border-electric-green/20 bevel-card-sm text-red outline-none focus:border-electric-green/50 focus:bg-electric-green/10 transition-all text-sm font-mono placeholder:text-red/20"
                      onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                    />
                  </div>

                  {status && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`text-[10px] font-bold uppercase tracking-widest text-red`}
                    >
                      {status}
                    </motion.p>
                  )}

                  <button
                    onClick={handleLogin}
                    disabled={isExploiting}
                    className="w-full py-4 bg-electric-green text-black font-black uppercase tracking-widest bevel-card-sm hover:bg-electric-green/80 transition-all glow-green flex items-center justify-center gap-2 text-sm disabled:opacity-50"
                  >
                    {isExploiting ? (
                      <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    ) : (
                      <>
                        <Zap className="w-4 h-4 fill-current" />
                        ACCESS SYSTEM
                      </>
                    )}
                  </button>

                  <div className="pt-8 border-t border-electric-green/10">
                    <p className="text-[10px] text-red/40 uppercase tracking-widest mb-4 font-mono">Payment Instructions</p>
                    <div className="bg-electric-green/5 bevel-card-sm p-5 text-center space-y-5 border border-electric-green/10">
                      <p className="text-[10px] text-red/60 leading-relaxed font-mono">
                        Scan the QR code below and pay <span className="font-bold text-red">Rs. 499/-</span> to receive your access token.
                      </p>
                      
                      <div className="flex justify-center p-4 bg-white bevel-card-sm border-4 border-electric-green/20">
                        <QRCodeCanvas 
                          value="upi://pay?pa=hackerstatuss@okaxis&pn=HackerStatus&am=499&cu=INR"
                          size={150}
                          level="H"
                          includeMargin={false}
                          fgColor="#000000"
                          bgColor="#ffffff"
                        />
                      </div>

                      <div className="flex items-center justify-center gap-2">
                        <div className="h-[1px] flex-1 bg-electric-green/10" />
                        <span className="text-[9px] text-red/30 uppercase font-mono tracking-widest">Secure Gateway</span>
                        <div className="h-[1px] flex-1 bg-electric-green/10" />
                      </div>

                      <p className="text-[9px] text-red/30 italic font-mono">
                        * Token will be provided after successful transaction verification.
                      </p>
                    </div>

                    <div className="mt-6 text-center">
                      <p className="text-[10px] text-red/40 uppercase tracking-widest font-mono mb-1">Helpline Support</p>
                      <a 
                        href="mailto:kaligptme@gmail.com" 
                        className="text-[11px] text-orange hover:brightness-110 transition-colors font-mono"
                      >
                        kaligptme@gmail.com
                      </a>
                    </div>
                  </div>

                  <div className="bg-electric-green/5 p-4 border-t border-electric-green/10 flex items-center justify-center gap-6">
                    <Globe className="w-4 h-4 text-electric-green/20" />
                    <Activity className="w-4 h-4 text-electric-green/20" />
                    <Search className="w-4 h-4 text-electric-green/20" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-20"
          >
            {/* Navbar */}
            <nav className="flex items-center justify-between px-6 md:px-10 py-4 sticky top-0 backdrop-blur-md z-50 transition-all duration-500 bg-cyber-glass/90 border-b border-electric-green/30 shadow-[0_0_20px_rgba(114,255,19,0.1)]">
              <div className="flex items-center gap-3 group cursor-pointer" onClick={triggerGlitch}>
                <Terminal className="text-electric-green group-hover:animate-pulse animate-pulse-glow" />
                <span className="font-bold text-lg tracking-tighter text-white glow-green text-glitch" data-text="-Linuxeh- Forensic">
                  -Linuxeh- Forensic
                </span>
              </div>

              {/* Professional Menu */}
              <div className="hidden lg:flex items-center gap-1 bevel-card-sm p-1 transition-all duration-500 bg-black/40 border border-electric-green/20 shadow-[inset_0_0_10px_rgba(114,255,19,0.1)]">
                {[
                  { id: 'INVESTIGATION', icon: Search, label: 'Investigation' },
                  { id: 'CYBER-INFO', icon: Activity, label: 'Cyber-Info' },
                  { id: 'TOOLS', icon: Zap, label: 'Tools' },
                  { id: 'CONTACTS', icon: Users, label: 'Contacts' },
                  { id: 'PROFILE', icon: User, label: 'Profile' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-6 py-2 bevel-card-sm text-[10px] font-bold uppercase tracking-widest transition-all duration-300 flex items-center gap-2 relative overflow-hidden group ${
                      activeTab === tab.id 
                        ? 'bg-electric-green text-black glow-green' 
                        : 'text-electric-green/50 hover:text-electric-green hover:bg-electric-green/5'
                    }`}
                  >
                    <tab.icon className={`w-3 h-3 ${activeTab === tab.id ? 'animate-pulse' : 'group-hover:scale-110 transition-transform'}`} />
                    {tab.label}
                    {activeTab === tab.id && (
                      <motion.div 
                        layoutId="activeTab"
                        className="absolute inset-0 bg-white/10 pointer-events-none"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 md:gap-4">
                <div className="flex items-center gap-1.5 md:gap-3">
                  <div className="flex items-center bevel-card-sm p-0.5 transition-all duration-300 bg-electric-green/5 border border-electric-green/20">
                    <button
                      onClick={() => setGlobalLang('EN')}
                      className={`px-2 md:px-3 py-1 text-[8px] md:text-[9px] font-bold bevel-card-sm transition-all ${
                        globalLang === 'EN' 
                          ? 'bg-electric-green text-black' 
                          : 'text-electric-green/40 hover:text-electric-green/60'
                      }`}
                    >
                      EN
                    </button>
                    <button
                      onClick={() => setGlobalLang('HI')}
                      className={`px-2 md:px-3 py-1 text-[8px] md:text-[9px] font-bold bevel-card-sm transition-all ${
                        globalLang === 'HI' 
                          ? 'bg-electric-green text-black' 
                          : 'text-electric-green/40 hover:text-electric-green/60'
                      }`}
                    >
                      HI
                    </button>
                  </div>
                </div>
                <button 
                  onClick={handleLogout}
                  className="p-2 bevel-card-sm transition-all duration-300 hover:bg-orange/10 text-orange/60 hover:text-orange border border-transparent hover:border-orange/30"
                >
                  <Lock className="w-4 h-4" />
                </button>
              </div>
            </nav>

            {/* Mobile Menu */}
            <div className="lg:hidden flex justify-center p-3 sticky top-[65px] z-40 backdrop-blur-sm overflow-x-auto no-scrollbar transition-all duration-300 bg-cyber-glass/80 border-b border-electric-green/10">
              <div className="flex gap-2 px-4">
                {[
                  { id: 'INVESTIGATION', icon: Search, label: 'Intel' },
                  { id: 'CYBER-INFO', icon: Activity, label: 'Cyber' },
                  { id: 'TOOLS', icon: Zap, label: 'Tools' },
                  { id: 'CONTACTS', icon: Users, label: 'Contacts' },
                  { id: 'PROFILE', icon: User, label: 'Profile' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-4 py-2.5 bevel-card-sm text-[9px] font-bold uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                      activeTab === tab.id 
                        ? 'bg-electric-green text-black glow-green' 
                        : 'text-electric-green/50 border border-electric-green/10 bg-black/20'
                    }`}
                  >
                    <tab.icon className="w-3 h-3" />
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Main Content */}
            <main className="p-4 md:p-6 w-full mx-auto">
              <AnimatePresence mode="wait">

                {activeTab === 'CONTACTS' && (
                  <motion.div
                    key="contacts"
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ type: "spring", damping: 20, stiffness: 100 }}
                    className="fixed inset-0 z-[60] bg-[#0D0D0D] overflow-y-auto"
                  >
                    <div className="absolute top-4 right-4 z-[70]">
                      <button 
                        onClick={() => setActiveTab('INVESTIGATION')}
                        className="p-2 bg-white/5 border border-white/10 text-white rounded-full hover:bg-white/10 transition-all"
                      >
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                    <ContactManager />
                  </motion.div>
                )}

                {activeTab === 'INVESTIGATION' && (
                  <motion.div
                    key="investigation"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-12"
                  >
                    <IntelligenceAgencies />
                    
                    <div className="mt-12">
                      <div className="flex items-center gap-3 mb-6">
                        <Terminal className="text-electric-green w-6 h-6 animate-pulse" />
                        <h2 className="text-xl font-bold tracking-[0.3em] text-white uppercase">
                          : SYSTEM_CORE_SPECIFICATIONS
                        </h2>
                      </div>
                      <MatrixTerminal 
                        text={`[ESTABLISHING_SECURE_CONNECTION...]
[NODE_ACTIVE: GLOBAL_INTELLIGENCE_GRID]
[DECRYPTING_AGENCY_PROTOCOLS...]

> CIA_NODE: Primary intelligence gathering for Western Hemisphere. Specialized in HUMINT and global covert operations.
> MOSSAD_LINK: Elite counter-terrorism and high-stakes extraction unit. Advanced cyber-infiltration capabilities.
> FSB_CORE: Internal security and counter-intelligence for the Russian Federation. Signal interception and SIGINT specialist.
> MI6_ACCESS: Global human intelligence network. Specialized in deep-cover operations and geopolitical strategic analysis.
> RAW_INTEL: Regional intelligence dominance in South Asia. Specialized in cross-border counter-insurgency and regional security.
> MSS_GRID: Comprehensive state security and foreign intelligence. Specialized in industrial espionage and cyber-defense.
> BND_DATA: Foreign intelligence service of Germany. Specialized in technical surveillance and European security coordination.

[SYSTEM_STATUS: OPTIMAL]
[ENCRYPTION: RSA-4096_ACTIVE]
[WELCOME_OPERATOR]`}
                      />
                    </div>
                  </motion.div>
                )}

                {activeTab === 'CYBER-INFO' && (
                  <motion.div
                    key="cyber-info"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <CyberSecurityHub 
                      paidAmount={paidAmount}
                      onLogout={handleLogout}
                    />
                  </motion.div>
                )}

                {activeTab === 'TOOLS' && (
                  <motion.div
                    key="tools"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ForensicTools />
                  </motion.div>
                )}

                {activeTab === 'PROFILE' && (
                  <motion.div
                    key="profile"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="space-y-8 relative p-4 md:p-8 bevel-card overflow-hidden transition-all duration-500 bg-cyber-glass/95 border border-electric-green/20 shadow-[0_0_50px_rgba(0,0,0,0.8)]"
                  >
                    <div className="relative z-10 mb-8 text-center">
                      <div className="flex justify-center mb-4">
                        <User className="w-12 h-12 text-electric-green glow-green" />
                      </div>
                      <h2 className="text-3xl font-bold mb-2 tracking-tighter text-glitch text-white" data-text="SYSTEM_PROFILE">
                        SYSTEM_PROFILE
                      </h2>
                      <p className="text-xs uppercase tracking-[0.4em] text-red/70">
                        Authentication Level: Admin_04
                      </p>
                    </div>

                    <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-8">
                      {/* User Identity Card */}
                      <div className="lg:col-span-1 glass-card p-8 bevel-card flex flex-col items-center text-center relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-electric-green to-transparent opacity-50" />
                        <div className="w-24 h-24 bevel-card p-1 mb-6 relative group border border-electric-green glow-green">
                          <div className="w-full h-full bevel-card flex items-center justify-center overflow-hidden bg-electric-green/10">
                            <img 
                              src={profilePhoto} 
                              alt="Profile" 
                              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <motion.div 
                            animate={{ rotate: 360 }}
                            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                            className="absolute -inset-2 border border-dashed bevel-card border-electric-green/30"
                          />
                        </div>
                        <h3 className="text-xl font-bold mb-1 tracking-tight text-white">
                          {profileName.toUpperCase()}
                        </h3>
                        <p className="text-[10px] font-mono mb-6 tracking-[0.3em] text-red">
                          UID: {tgUser ? tgUser.id : '0x' + Math.random().toString(16).slice(2, 10).toUpperCase()}
                        </p>
                        <div className="w-full space-y-3">
                          <div className="flex justify-between text-[10px] uppercase tracking-widest border-b pb-2 border-electric-green/5">
                            <span className="text-red/40">Access_Level</span>
                            <span className="font-bold text-red">LEVEL_04</span>
                          </div>
                          <div className="flex justify-between text-[10px] uppercase tracking-widest border-b pb-2 border-electric-green/5">
                            <span className="text-red/40">Status</span>
                            <span className="text-red font-bold">VERIFIED</span>
                          </div>
                          <div className="flex justify-between text-[10px] uppercase tracking-widest">
                            <span className="text-red/40">Balance</span>
                            <span className="font-bold text-white">₹{paidAmount}</span>
                          </div>
                        </div>
                      </div>

                      {/* System & Network Stats */}
                      <div className="lg:col-span-2 space-y-6">
                        {/* Profile Edit Section */}
                        <div className="glass-card p-6 bevel-card">
                          <h3 className="text-sm font-bold mb-4 flex items-center gap-2 text-white">
                            <User className="w-4 h-4 text-electric-green" /> EDIT_IDENTITY_PROTOCOLS
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                              <label className="text-[10px] uppercase tracking-widest text-red/60">Access_Name</label>
                              <input 
                                type="text"
                                value={profileName}
                                onChange={(e) => setProfileName(e.target.value)}
                                className="w-full bg-black/40 border border-electric-green/20 bevel-card-sm px-4 py-2 text-sm text-red focus:outline-none focus:border-electric-green/50"
                                placeholder="Enter Name..."
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] uppercase tracking-widest text-red/60">Avatar_URL</label>
                              <div className="flex gap-2">
                                <input 
                                  type="text"
                                  value={profilePhoto}
                                  onChange={(e) => setProfilePhoto(e.target.value)}
                                  className="flex-1 bg-black/40 border border-electric-green/20 bevel-card-sm px-4 py-2 text-sm text-red focus:outline-none focus:border-electric-green/50"
                                  placeholder="Photo URL..."
                                />
                                <input 
                                  type="file"
                                  id="photo-upload"
                                  className="hidden"
                                  accept="image/*"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onloadend = () => {
                                        setProfilePhoto(reader.result as string);
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }}
                                />
                                <label 
                                  htmlFor="photo-upload"
                                  className="px-4 py-2 bg-electric-green/10 border border-electric-green/20 bevel-card-sm text-[10px] font-bold uppercase tracking-widest text-electric-green cursor-pointer hover:bg-electric-green/20 transition-all flex items-center"
                                >
                                  Upload
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="glass-card p-6 bevel-card">
                            <h3 className="text-sm font-bold mb-4 flex items-center gap-2 text-white">
                              <Activity className="w-4 h-4 text-electric-green" /> NETWORK_STATUS
                            </h3>
                          <div className="space-y-4">
                            {[
                              { label: 'Uplink', status: 'STABLE', color: 'text-red' },
                              { label: 'Latency', status: '12ms', color: 'text-red' },
                              { label: 'Encryption', status: 'AES-256', color: 'text-orange' },
                              { label: 'Nodes', status: '14 ACTIVE', color: 'text-white' }
                            ].map((item) => (
                              <div key={item.label} className="flex justify-between text-[10px] uppercase tracking-widest">
                                <span className="text-red/40">{item.label}</span>
                                <span className={item.color}>{item.status}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="glass-card p-6 bevel-card">
                          <h3 className="text-sm font-bold mb-4 flex items-center gap-2 text-white">
                            <Globe className="w-4 h-4 text-electric-green" /> GLOBAL_TRAFFIC
                          </h3>
                          <div className="h-32 flex items-end gap-1">
                            {[40, 70, 45, 90, 65, 80, 55, 95, 75, 60].map((h, i) => (
                              <motion.div 
                                key={i}
                                initial={{ height: 0 }}
                                animate={{ height: `${h}%` }}
                                transition={{ delay: i * 0.1 }}
                                className="flex-1 bg-electric-green/20 border-t border-electric-green"
                              />
                            ))}
                          </div>
                        </div>
                        <div className="md:col-span-2 glass-card p-6 bevel-card">
                          <h3 className="text-sm font-bold mb-4 flex items-center gap-2 text-white">
                            <Shield className="w-4 h-4 text-electric-green" /> SECURITY_LOGS
                          </h3>
                          <div className="text-[8px] font-mono space-y-1 h-32 overflow-y-auto custom-scrollbar text-red/30">
                            <p>[14:22:01] AUTH_SUCCESS: USER_092</p>
                            <p>[14:22:05] NODE_SYNC: ASIA_NORTH</p>
                            <p className="text-orange/50">[14:22:12] BRUTE_FORCE_DETECTED: IP_88.12.3</p>
                            <p>[14:22:15] FIREWALL_REINFORCED</p>
                            <p>[14:22:20] ENCRYPTION_ROTATED</p>
                            <p>[14:23:45] SESSION_ENCRYPTED: RSA-4096</p>
                            <p>[14:24:12] PACKET_FILTER_ACTIVE</p>
                            <p>[14:25:01] HEARTBEAT_STABLE</p>
                          </div>
                        </div>

                        <div className="md:col-span-2">
                          <MissionLog />
                        </div>
                      </div>
                    </div>

                      {/* Model Specifications Terminal */}
                      <div className="lg:col-span-3">
                        <h3 className="text-sm font-bold mb-4 flex items-center gap-2 text-white">
                          <Zap className="w-4 h-4 text-electric-green" /> MODEL_SPECIFICATIONS
                        </h3>
                        <MatrixTerminal 
                          text={`[SYSTEM_INITIALIZATION_COMPLETE]
[DECRYPTING_INVESTIGATION_TOOLS...]

> CIA_PROTOCOL: Advanced human intelligence (HUMINT) gathering and analysis framework.
> MOSSAD_ENGINE: High-precision counter-terrorism and tactical extraction logic.
> FSB_INTERFACE: Comprehensive signal intelligence (SIGINT) and internal security monitoring.
> MI6_NETWORK: Strategic geopolitical analysis and deep-cover operative coordination.
> RAW_GATEWAY: South Asian regional security and counter-insurgency intelligence processing.
> MSS_SYSTEM: Large-scale foreign intelligence and industrial security protocols.
> BND_SURVEILLANCE: Technical surveillance and international intelligence coordination.

[ACCESS_LEVEL: LEVEL_04_ADMIN]
[STATUS: ALL_SYSTEMS_OPERATIONAL]`}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
