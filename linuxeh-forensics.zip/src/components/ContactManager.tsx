import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  UserPlus, 
  Users, 
  Phone, 
  Mail, 
  MapPin, 
  Share2, 
  Download, 
  Trash2, 
  Lock, 
  Unlock,
  Camera,
  FileText,
  Table,
  X,
  Search,
  Eye,
  Info,
  Folder,
  ChevronLeft
} from 'lucide-react';
import CryptoJS from 'crypto-js';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';

// Encryption Key (In a real app, this shouldn't be hardcoded like this, but for this requirement we use it)
const ENCRYPTION_KEY = '25021993_SECURE_KEY';

interface Contact {
  id: string;
  name: string;
  mobile: string;
  email: string;
  address: string;
  social: string;
  photo: string; // Base64
  category: string;
}

export const ContactManager: React.FC = () => {
  const [isLocked, setIsLocked] = useState(true);
  const [pin, setPin] = useState('');
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState('');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    address: '',
    social: '',
    photo: '',
    category: 'General'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const importFileInputRef = useRef<HTMLInputElement>(null);

  // Load contacts from localStorage
  useEffect(() => {
    if (!isLocked) {
      loadContacts();
    }
  }, [isLocked]);

  const loadContacts = () => {
    try {
      const encryptedData = localStorage.getItem('encrypted_contacts');
      if (encryptedData) {
        const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
        const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        setContacts(decryptedData || []);
      }
    } catch (err) {
      console.error('Failed to decrypt contacts:', err);
      setContacts([]);
    }
  };

  const saveContacts = (newContacts: Contact[]) => {
    const encryptedData = CryptoJS.AES.encrypt(JSON.stringify(newContacts), ENCRYPTION_KEY).toString();
    localStorage.setItem('encrypted_contacts', encryptedData);
    setContacts(newContacts);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '25021993') {
      setIsLocked(false);
      setError('');
    } else {
      setError('INVALID PIN. ACCESS DENIED.');
      setPin('');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newContact: Contact = {
      ...formData,
      id: Date.now().toString()
    };
    const updatedContacts = [...contacts, newContact];
    saveContacts(updatedContacts);
    setFormData({ name: '', mobile: '', email: '', address: '', social: '', photo: '', category: 'General' });
    setShowForm(false);
  };

  const deleteContact = (id: string) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Contact',
      message: 'Are you sure you want to permanently delete this contact? This action cannot be undone.',
      onConfirm: () => {
        const updatedContacts = contacts.filter(c => c.id !== id);
        saveContacts(updatedContacts);
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const clearAllContacts = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'Clear All Contacts',
      message: 'WARNING: This will permanently delete ALL contacts from your secure database. Are you absolutely sure?',
      onConfirm: () => {
        saveContacts([]);
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const exportToPDF = async () => {
    const element = document.getElementById('pdf-export-table');
    if (!element) return;

    // Temporarily show the element to capture it
    element.style.display = 'block';
    
    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('contacts.pdf');
    } catch (err) {
      console.error('PDF Export Error:', err);
      alert('Failed to export PDF');
    } finally {
      element.style.display = 'none';
    }
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(contacts.map(({ photo, id, ...rest }) => rest));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Contacts');
    XLSX.writeFile(workbook, 'contacts.xlsx');
  };
  
  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws) as any[];
        
        const importedContacts: Contact[] = data.map((item, index) => ({
          id: (Date.now() + index).toString(),
          name: item.name || item.Name || 'Unknown',
          mobile: item.mobile || item.Mobile || '',
          email: item.email || item.Email || '',
          address: item.address || item.Address || '',
          social: item.social || item.Social || '',
          category: item.category || item.Category || 'General',
          photo: '' // Photos are usually not in Excel
        }));

        if (importedContacts.length > 0) {
          const updatedContacts = [...contacts, ...importedContacts];
          saveContacts(updatedContacts);
          alert(`Successfully imported ${importedContacts.length} contacts.`);
        } else {
          alert('No valid contact data found in the file.');
        }
      } catch (err) {
        console.error('Import Error:', err);
        alert('Failed to import contacts. Please check the file format.');
      }
      // Reset input
      if (importFileInputRef.current) importFileInputRef.current.value = '';
    };
    reader.readAsBinaryString(file);
  };

  const downloadTemplate = () => {
    const template = [
      { name: 'John Doe', mobile: '1234567890', email: 'john@example.com', address: '123 Street', social: '@john', category: 'General' }
    ];
    const worksheet = XLSX.utils.json_to_sheet(template);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Template');
    XLSX.writeFile(workbook, 'contact_import_template.xlsx');
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    String(c.mobile || '').includes(searchQuery) ||
    c.category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = Array.from(new Set(contacts.map(c => c.category || 'General')));

  const contactsToDisplay = searchQuery 
    ? filteredContacts 
    : selectedCategory 
      ? filteredContacts.filter(c => c.category === selectedCategory)
      : [];

  if (isLocked) {
    return (
      <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-black/40 border border-red/20 p-8 rounded-2xl backdrop-blur-xl"
        >
          <div className="flex flex-col items-center mb-8">
            <div className="p-4 bg-red/10 rounded-full mb-4">
              <Lock className="w-12 h-12 text-red" />
            </div>
            <h2 className="text-2xl font-bold text-white tracking-widest uppercase">Secure Access</h2>
            <p className="text-red/50 text-xs mt-2 uppercase tracking-tighter">Enter PIN to decrypt database</p>
          </div>

          <form onSubmit={handlePinSubmit} className="space-y-6">
            <div>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="ENTER PIN"
                className="w-full bg-black/50 border border-orange/30 rounded-xl px-4 py-3 text-center text-2xl tracking-[1em] text-orange focus:outline-none focus:border-orange transition-all"
                maxLength={8}
                autoFocus
              />
              {error && <p className="text-red text-[10px] mt-2 text-center uppercase font-bold">{error}</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-electric-green text-black font-bold py-3 rounded-xl hover:bg-electric-green/80 transition-all uppercase tracking-widest shadow-[0_0_20px_rgba(114,255,19,0.3)]"
            >
              Authorize
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white p-4 md:p-8 font-sans">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Users className="text-red w-8 h-8" />
              <h1 className="text-3xl font-bold tracking-tight">Contact Manager</h1>
            </div>
            <p className="text-white/40 text-sm">Securely encrypted database // AES-256</p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button 
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 bg-electric-green text-black px-6 py-2.5 rounded-xl font-bold hover:bg-electric-green/80 transition-all shadow-lg shadow-electric-green/20"
            >
              <UserPlus className="w-4 h-4" /> Add Contact
            </button>
            <button 
              onClick={exportToPDF}
              className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl font-medium hover:bg-white/10 transition-all"
            >
              <FileText className="w-4 h-4" /> PDF
            </button>
            <button 
              onClick={exportToExcel}
              className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl font-medium hover:bg-white/10 transition-all"
            >
              <Table className="w-4 h-4" /> Export Excel
            </button>
            <button 
              onClick={() => importFileInputRef.current?.click()}
              className="flex items-center gap-2 bg-orange/10 text-orange border border-orange/20 px-4 py-2.5 rounded-xl font-medium hover:bg-orange hover:text-white transition-all"
            >
              <Download className="w-4 h-4 rotate-180" /> Import Excel
            </button>
            <input 
              type="file" 
              ref={importFileInputRef} 
              onChange={importFromExcel} 
              className="hidden" 
              accept=".xlsx, .xls, .csv" 
            />
            <button 
              onClick={downloadTemplate}
              className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl font-medium hover:bg-white/10 transition-all"
              title="Download Excel Template"
            >
              <Table className="w-4 h-4 opacity-50" /> Template
            </button>
            <button 
              onClick={clearAllContacts}
              className="flex items-center gap-2 bg-red/10 text-red border border-red/20 px-4 py-2.5 rounded-xl font-medium hover:bg-red hover:text-white transition-all"
            >
              <Trash2 className="w-4 h-4" /> Clear All
            </button>
            <button 
              onClick={() => setIsLocked(true)}
              className="p-2.5 bg-orange/10 text-orange border border-orange/20 rounded-xl hover:bg-orange hover:text-white transition-all"
            >
              <Unlock className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Search Bar */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20 w-5 h-5" />
          <input 
            type="text"
            placeholder="Search contacts by name or mobile..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-orange/50 transition-all"
          />
        </div>

        {/* Hidden Table for PDF Export */}
        <div id="pdf-export-table" style={{ display: 'none', padding: '40px', color: '#000', backgroundColor: '#fff', width: '800px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '20px', borderBottom: '2px solid #000', paddingBottom: '10px' }}>Contact List</h1>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#f3f4f6' }}>
                <th style={{ border: '1px solid #d1d5db', padding: '12px', textAlign: 'left' }}>Name</th>
                <th style={{ border: '1px solid #d1d5db', padding: '12px', textAlign: 'left' }}>Mobile</th>
                <th style={{ border: '1px solid #d1d5db', padding: '12px', textAlign: 'left' }}>Email</th>
                <th style={{ border: '1px solid #d1d5db', padding: '12px', textAlign: 'left' }}>Address</th>
                <th style={{ border: '1px solid #d1d5db', padding: '12px', textAlign: 'left' }}>Social</th>
              </tr>
            </thead>
            <tbody>
              {contacts.map((c) => (
                <tr key={c.id}>
                  <td style={{ border: '1px solid #d1d5db', padding: '12px' }}>{c.name}</td>
                  <td style={{ border: '1px solid #d1d5db', padding: '12px' }}>{c.mobile}</td>
                  <td style={{ border: '1px solid #d1d5db', padding: '12px' }}>{c.email}</td>
                  <td style={{ border: '1px solid #d1d5db', padding: '12px' }}>{c.address}</td>
                  <td style={{ border: '1px solid #d1d5db', padding: '12px' }}>{c.social}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Folders or Contacts */}
        {!searchQuery && !selectedCategory ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(cat)}
                className="flex flex-col items-center p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-red/30 transition-all group"
              >
                <div className="p-4 bg-red/10 rounded-xl mb-3 group-hover:bg-red/20 transition-colors">
                  <Folder className="w-8 h-8 text-red" />
                </div>
                <span className="text-sm font-bold uppercase tracking-widest">{cat}</span>
                <span className="text-[10px] text-white/40 mt-1">
                  {contacts.filter(c => c.category === cat).length} Contacts
                </span>
              </motion.button>
            ))}
            {categories.length === 0 && (
              <div className="col-span-full py-20 text-center">
                <div className="inline-block p-6 bg-white/5 rounded-full mb-4">
                  <Folder className="w-12 h-12 text-white/10" />
                </div>
                <h3 className="text-xl font-medium text-white/40">No folders yet</h3>
                <p className="text-white/20 text-sm mt-1">Add a contact to create your first folder</p>
              </div>
            )}
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                {!searchQuery && (
                  <button 
                    onClick={() => setSelectedCategory(null)}
                    className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-all"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                )}
                <h2 className="text-xl font-bold uppercase tracking-widest flex items-center gap-3">
                  {searchQuery ? (
                    <><Search className="w-5 h-5 text-red" /> Search Results</>
                  ) : (
                    <><Folder className="w-5 h-5 text-red" /> {selectedCategory}</>
                  )}
                </h2>
              </div>
              <span className="text-xs text-white/40 uppercase tracking-widest">
                {contactsToDisplay.length} Contacts Found
              </span>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 lg:grid-cols-10 xl:grid-cols-12 gap-2">
              <AnimatePresence>
                {contactsToDisplay.map((contact) => (
                  <motion.div
                    key={contact.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="group relative bg-white/5 border border-white/10 rounded-xl p-1.5 hover:bg-white/[0.08] transition-all duration-300 hover:border-red/30 flex flex-col items-center text-center hover-glow"
                  >
                    <div className="absolute top-1 right-1 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => setSelectedContact(contact)}
                        className="p-0.5 text-white/40 hover:text-orange transition-colors"
                      >
                        <Eye className="w-2 h-2" />
                      </button>
                    </div>

                    <div className="w-8 h-8 rounded-lg overflow-hidden mb-1 border border-red/10 group-hover:border-red/30 transition-all flex-shrink-0">
                      {contact.photo ? (
                        <img src={contact.photo} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-red/5 flex items-center justify-center">
                          <Users className="w-3 h-3 text-red/20" />
                        </div>
                      )}
                    </div>
                    
                    <h3 className="text-[8px] font-medium truncate w-full px-0.5 text-white/70 group-hover:text-white transition-colors">{contact.name}</h3>
                  </motion.div>
                ))}
              </AnimatePresence>

              {contactsToDisplay.length === 0 && (
                <div className="col-span-full py-20 text-center">
                  <div className="inline-block p-6 bg-white/5 rounded-full mb-4">
                    <Users className="w-12 h-12 text-white/10" />
                  </div>
                  <h3 className="text-xl font-medium text-white/40">No contacts found</h3>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Add Contact Modal */}
        <AnimatePresence>
          {showForm && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="w-full max-w-2xl bg-[#141414] border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
              >
                <div className="flex items-center justify-between p-6 border-b border-white/5">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <UserPlus className="text-red w-5 h-5" /> New Contact
                  </h2>
                  <button onClick={() => setShowForm(false)} className="p-2 hover:bg-white/5 rounded-full transition-all">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                  <div className="flex flex-col md:flex-row gap-8">
                    {/* Photo Upload */}
                    <div className="flex flex-col items-center gap-4">
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="w-32 h-32 rounded-3xl bg-white/5 border-2 border-dashed border-white/10 flex flex-col items-center justify-center cursor-pointer hover:border-red/50 hover:bg-red/5 transition-all overflow-hidden relative group"
                      >
                        {formData.photo ? (
                          <img src={formData.photo} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <>
                            <Camera className="w-8 h-8 text-white/20 mb-2" />
                            <span className="text-[10px] text-white/40 uppercase font-bold">Upload Photo</span>
                          </>
                        )}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                          <Camera className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleImageUpload} 
                        className="hidden" 
                        accept="image/*" 
                      />
                    </div>

                    {/* Fields */}
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Full Name</label>
                        <input
                          required
                          type="text"
                          value={formData.name}
                          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50"
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Mobile Number</label>
                        <input
                          required
                          type="tel"
                          value={formData.mobile}
                          onChange={(e) => setFormData(prev => ({ ...prev, mobile: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50"
                          placeholder="+1 234 567 890"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Email Address</label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50"
                          placeholder="john@example.com"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Social ID</label>
                        <input
                          type="text"
                          value={formData.social}
                          onChange={(e) => setFormData(prev => ({ ...prev, social: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50"
                          placeholder="@johndoe"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Category / Folder</label>
                        <input
                          type="text"
                          value={formData.category}
                          onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50"
                          placeholder="General, Family, Work..."
                        />
                      </div>
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-[10px] uppercase font-bold text-white/40 ml-1">Address</label>
                        <textarea
                          value={formData.address}
                          onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 focus:outline-none focus:border-red/50 min-h-[80px]"
                          placeholder="123 Secure St, Crypto City"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-white/5">
                    <button
                      type="button"
                      onClick={() => setShowForm(false)}
                      className="flex-1 px-6 py-3 rounded-xl font-bold border border-white/10 hover:bg-white/5 transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-red text-white px-6 py-3 rounded-xl font-bold hover:bg-red/80 transition-all shadow-lg shadow-red/20"
                    >
                      Save Contact
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Sticky Quick View Bar */}
        <AnimatePresence>
          {selectedContact && !showForm && (
            <motion.div
              initial={{ y: 100, x: '-50%', opacity: 0 }}
              animate={{ y: 0, x: '-50%', opacity: 1 }}
              exit={{ y: 100, x: '-50%', opacity: 0 }}
              className="fixed bottom-8 left-1/2 z-[90] w-auto"
            >
              <div className="bg-black/60 backdrop-blur-2xl border border-white/10 rounded-full px-5 py-2.5 flex items-center gap-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
                <div className="w-8 h-8 rounded-full overflow-hidden border border-red/30 flex-shrink-0">
                  {selectedContact.photo ? (
                    <img src={selectedContact.photo} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-red/10 flex items-center justify-center">
                      <Users className="w-4 h-4 text-red/40" />
                    </div>
                  )}
                </div>
                <div className="flex flex-col min-w-[100px]">
                  <span className="text-[10px] font-bold text-white truncate max-w-[150px] uppercase tracking-wider">{selectedContact.name}</span>
                  <span className="text-[9px] text-red font-mono tracking-tighter">{selectedContact.mobile}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setSelectedContact(selectedContact)}
                    className="p-2 bg-orange/10 rounded-full text-orange hover:bg-orange hover:text-white transition-all"
                    title="Full View"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <div className="w-px h-4 bg-white/10 mx-1" />
                  <button 
                    onClick={() => setSelectedContact(null)}
                    className="p-2 text-white/20 hover:text-white transition-all"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Contact Details Modal */}
        <AnimatePresence>
          {selectedContact && (
            <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="w-full max-w-lg bg-[#141414] border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
              >
                <div className="relative h-40 bg-gradient-to-br from-red/20 to-orange/20">
                  <button 
                    onClick={() => setSelectedContact(null)}
                    className="absolute top-4 right-4 p-2 bg-black/40 hover:bg-black/60 rounded-full text-white transition-all z-10"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <div className="absolute -bottom-12 left-8">
                    <div className="w-24 h-24 rounded-3xl overflow-hidden border-4 border-[#141414] bg-[#141414] shadow-xl">
                      {selectedContact.photo ? (
                        <img src={selectedContact.photo} alt={selectedContact.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full bg-red/10 flex items-center justify-center">
                          <Users className="w-10 h-10 text-red/40" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-16 p-8 space-y-6">
                  <div>
                    <h2 className="text-3xl font-bold text-white">{selectedContact.name}</h2>
                    <p className="text-red font-mono text-lg mt-1">{selectedContact.mobile}</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                      <Mail className="w-5 h-5 text-red mt-1" />
                      <div>
                        <p className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Email Address</p>
                        <p className="text-white/80">{selectedContact.email || 'Not provided'}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                      <MapPin className="w-5 h-5 text-red mt-1" />
                      <div>
                        <p className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Physical Address</p>
                        <p className="text-white/80">{selectedContact.address || 'Not provided'}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                      <Share2 className="w-5 h-5 text-red mt-1" />
                      <div>
                        <p className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Social Identity</p>
                        <p className="text-white/80">{selectedContact.social || 'Not provided'}</p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button
                      onClick={() => {
                        const text = `Contact: ${selectedContact.name}\nMobile: ${selectedContact.mobile}\nEmail: ${selectedContact.email}\nAddress: ${selectedContact.address}\nSocial: ${selectedContact.social}`;
                        navigator.clipboard.writeText(text);
                        alert('Contact details copied to clipboard');
                      }}
                      className="flex-1 flex items-center justify-center gap-2 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-bold transition-all"
                    >
                      <Share2 className="w-4 h-4" /> Copy Details
                    </button>
                    <button
                      onClick={() => setSelectedContact(null)}
                      className="flex-1 py-3 bg-red text-white rounded-xl font-bold hover:bg-red/80 transition-all"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Confirmation Dialog */}
        <AnimatePresence>
          {confirmDialog.isOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="w-full max-w-md bg-[#1a1a1a] border border-red-500/30 rounded-3xl p-8 shadow-2xl"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-red-500/10 rounded-2xl">
                    <Trash2 className="w-8 h-8 text-red-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-white">{confirmDialog.title}</h2>
                </div>
                <p className="text-white/60 mb-8 leading-relaxed">
                  {confirmDialog.message}
                </p>
                <div className="flex gap-4">
                  <button
                    onClick={() => setConfirmDialog(prev => ({ ...prev, isOpen: false }))}
                    className="flex-1 px-6 py-3 rounded-xl font-bold border border-white/10 hover:bg-white/5 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmDialog.onConfirm}
                    className="flex-1 bg-red-500 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-600 transition-all shadow-lg shadow-red-500/20"
                  >
                    Confirm
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
