import React, { useState, useEffect } from 'react';
import { 
  Shield,
  ShieldCheck, 
  Search, 
  Loader2, 
  Target, 
  ExternalLink, 
  BookOpen, 
  Lock, 
  Zap, 
  Send,
  History,
  Download,
  User,
  Trash2,
  Clock,
  ArrowRight,
  ShieldAlert,
  FileText,
  Globe,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import Markdown from 'react-markdown';
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import { SearchingState } from './SearchingState';

// Intelligence Nodes Configuration
const INTELLIGENCE_NODES = [
  { id: 'cyber', name: 'Cyber Security', icon: ShieldCheck, url: 'https://www.cisa.gov' },
  { id: 'threat', name: 'Threat Intel', icon: Target, url: 'https://www.threatintel.com' },
  { id: 'hibp', name: 'HIBP_CHECK', icon: ShieldAlert, url: 'https://haveibeenpwned.com' },
  { id: 'gov', name: 'Gov Services', icon: FileText, url: 'https://serviceonline.gov.in/userCertificate.html' },
  { id: 'dgft', name: 'DGFT COO', icon: Globe, url: 'https://coo.dgft.gov.in/' },
  { id: 'data_gov', name: 'Open Data India', icon: Database, url: 'https://data.gov.in' },
  { id: 'vuln', name: 'Vulnerability', icon: Lock, url: 'https://cve.mitre.org' },
];

const SECURITY_SUB_NODES = [
  { name: 'Malware Analysis' },
  { name: 'Phishing Detection' },
  { name: 'Ransomware Tracking' },
  { name: 'Zero-Day Alerts' },
  { name: 'APT Monitoring' },
  { name: 'Cloud Security' },
  { name: 'IoT Vulnerabilities' },
];

const HIBP_SUB_NODES = [
  { name: 'Check Account Breaches' },
  { name: 'Check Account Pastes' },
  { name: 'Check Password Strength' },
  { name: 'Latest Data Breaches' },
];

const GOV_SUB_NODES = [
  { name: 'Track Application' },
  { name: 'Download Certificate' },
  { name: 'Check Caste Certificate' },
  { name: 'Income Certificate Status' },
  { name: 'Birth/Death Certificate' },
  { name: 'Residence Certificate' },
];

const DGFT_SUB_NODES = [
  { name: 'Apply for COO' },
  { name: 'Verify Certificate' },
  { name: 'Exporter Registration' },
  { name: 'Track COO Status' },
  { name: 'DGFT Helpdesk' },
  { name: 'Trade Notices' },
];

const DATA_GOV_SUB_NODES = [
  { name: 'Census Data' },
  { name: 'Transport Statistics' },
  { name: 'Agriculture Data' },
  { name: 'Education Stats' },
  { name: 'Health Indicators' },
  { name: 'Economic Surveys' },
  { name: 'Environment Data' },
];

interface SearchHistoryItem {
  id: string;
  query: string;
  nodeName: string;
  timestamp: number;
  result: string;
}

interface CyberSecurityHubProps {
  paidAmount?: string;
  onLogout?: () => void;
}

export const CyberSecurityHub: React.FC<CyberSecurityHubProps> = ({ paidAmount = '0', onLogout }) => {
  const [activeNode, setActiveNode] = useState(INTELLIGENCE_NODES[0]);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sources, setSources] = useState<{ title: string; uri: string }[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [currentLang, setCurrentLang] = useState<'EN' | 'HI'>('EN');
  const [translatedResult, setTranslatedResult] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [view, setView] = useState<'SEARCH' | 'HISTORY' | 'PROFILE'>('SEARCH');
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);

  // Debounced loading state
  const [showSearchingState, setShowSearchingState] = useState(false);
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isLoading) {
      timer = setTimeout(() => setShowSearchingState(true), 400);
    } else {
      setShowSearchingState(false);
    }
    return () => clearTimeout(timer);
  }, [isLoading]);

  // Initialize Gemini
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  const downloadPDF = () => {
    const doc = new jsPDF();
    const content = currentLang === 'HI' ? translatedResult : result;
    
    if (!content) return;

    doc.setFontSize(20);
    doc.setTextColor(255, 0, 0); // Red
    doc.text("CYBER-INFO INTELLIGENCE REPORT", 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Node: ${activeNode.name}`, 10, 30);
    doc.text(`Date: ${new Date().toLocaleString()}`, 10, 35);
    
    doc.setDrawColor(255, 0, 0);
    doc.line(10, 40, 200, 40);

    doc.setFontSize(12);
    doc.setTextColor(0);
    const splitText = doc.splitTextToSize(content.replace(/[#*`]/g, ''), 180);
    doc.text(splitText, 10, 50);

    doc.save(`cyber_intel_${Date.now()}.pdf`);
  };

  const translateResult = async (targetLang: 'HI') => {
    if (!result) return;
    setIsTranslating(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Translate the following technical cyber security report into Hindi. Keep technical terms like "Malware", "Phishing", "Firewall" in English but written in Hindi script if appropriate, or keep them in English. Ensure the tone is professional and authoritative: \n\n${result}`,
      });
      setTranslatedResult(response.text || 'Translation failed.');
      setCurrentLang('HI');
    } catch (err) {
      console.error('Translation Error:', err);
      setError('Translation node failed to respond.');
    } finally {
      setIsTranslating(false);
    }
  };

  const sendToTelegram = async () => {
    if (!result) return;
    setIsSending(true);
    try {
      const botToken = '8206372673:AAEK0l594tMkLSNPGsLB0KzrdtWzO6MU1zE';
      const chatId = (window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id;
      
      if (!chatId) {
        setError('Telegram session not detected. Please open in Telegram.');
        return;
      }

      const message = `🛡 *CYBER-INFO INTELLIGENCE REPORT*\n\n*Node:* ${activeNode.name}\n*Query:* ${query}\n\n${result.substring(0, 3500)}...`;

      const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      });

      if (response.ok) {
        setSendSuccess(true);
        setTimeout(() => setSendSuccess(false), 3000);
      } else {
        throw new Error('Failed to transmit data');
      }
    } catch (err) {
      setError('Failed to transmit intelligence to Telegram node.');
    } finally {
      setIsSending(false);
    }
  };

  const searchHub = async (e?: React.FormEvent | string) => {
    if (e && typeof e !== 'string') e.preventDefault();
    const searchQuery = typeof e === 'string' ? e : query;
    
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);
    setSources([]);
    setTranslatedResult(null);
    setCurrentLang('EN');

    try {
      // Special handling for HIBP node
      if (activeNode.id === 'hibp') {
        const hibpKey = process.env.HIBP_API_KEY;
        
        // If it's a password check, we don't need a key
        if (searchQuery.toLowerCase().includes('password')) {
          const password = searchQuery.split(' ').pop() || '';
          if (password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-1', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
            
            const prefix = hashHex.substring(0, 5);
            const suffix = hashHex.substring(5);
            
            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            const text = await response.text();
            const lines = text.split('\n');
            const match = lines.find(line => line.startsWith(suffix));
            
            if (match) {
              const count = match.split(':')[1];
              setResult(`### ⚠️ PWNED_PASSWORD_DETECTED\n\nThis password has been seen **${count.trim()}** times in data breaches. \n\n**Recommendation:** Change this password immediately and use a unique, complex password for every account.`);
            } else {
              setResult(`### ✅ PASSWORD_SECURE\n\nThis password was not found in any known data breaches. \n\n**Note:** This doesn't mean it's "safe", just that it hasn't been leaked yet.`);
            }
            setIsLoading(false);
            return;
          }
        }

        if (!hibpKey) {
          setResult(`### 🛡 HIBP_INTEGRATION_ACTIVE\n\nTo perform real-time account breach checks, please configure your **HIBP_API_KEY** in the system environment.\n\n**Node Status:** Simulation Mode Active.\n\n**Query:** ${searchQuery}\n\n*Simulated Result:* This account appears in 3 known breaches (LinkedIn, Adobe, Canva).`);
          setIsLoading(false);
          return;
        }

        // Real HIBP Account Check
        const response = await fetch(`https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(searchQuery)}?truncateResponse=false`, {
          headers: { 'hibp-api-key': hibpKey, 'user-agent': 'Cyber-Info-Hub' }
        });

        if (response.status === 404) {
          setResult(`### ✅ NO_BREACHES_FOUND\n\nGood news! The account **${searchQuery}** was not found in any known data breaches indexed by Have I Been Pwned.`);
        } else if (response.ok) {
          const breaches = await response.json();
          let report = `### ⚠️ BREACHES_DETECTED (${breaches.length})\n\nThe account **${searchQuery}** has been found in the following data breaches:\n\n`;
          breaches.forEach((b: any) => {
            report += `#### ${b.Title} (${b.BreachDate})\n- **Data Classes:** ${b.DataClasses.join(', ')}\n- **Description:** ${b.Description.replace(/<[^>]*>?/gm, '')}\n\n`;
          });
          setResult(report);
        } else {
          throw new Error(`HIBP API Error: ${response.status}`);
        }
        setIsLoading(false);
        return;
      }

      const systemInstruction = activeNode.id === 'gov' 
        ? `Act as a government services assistant for India. Provide detailed information on how to track applications, download certificates, and check statuses on the ServicePlus portal (serviceonline.gov.in). 
           Format your response into distinct sections starting with "### [SECTION_NAME]". 
           For example: "### [SERVICE_OVERVIEW]", "### [APPLICATION_STEPS]", "### [DOCUMENT_REQUIREMENTS]".
           If the user asks for a specific certificate, provide direct steps and links. Official portal: https://serviceonline.gov.in/userCertificate.html.`
        : activeNode.id === 'dgft'
        ? `Act as a trade intelligence assistant for DGFT (Directorate General of Foreign Trade, India). 
           Provide detailed information on the Common Digital Platform for Certificate of Origin (COO). 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [EXPORTER_REGISTRATION]", "### [COO_APPLICATION_PROCESS]", "### [DIGITAL_SIGNATURE_GUIDE]".
           Help users with steps for registration, applying for COO, and tracking status on https://coo.dgft.gov.in/.`
        : activeNode.id === 'data_gov'
        ? `Act as an Open Data Intelligence operative for the Government of India. 
           Provide detailed information about datasets available on https://data.gov.in. 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [DATASET_SUMMARY]", "### [API_INTEGRATION_GUIDE]", "### [ECONOMIC_INSIGHTS]".
           Explain how to use the Open Data APIs and provide insights from latest reports. Use a professional, data-driven "hacker-style" markdown.`
        : activeNode.id === 'cyber'
        ? `Act as a senior CISA cyber security analyst. Provide technical intelligence reports based on CISA guidelines and NIST frameworks. 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [THREAT_LANDSCAPE]", "### [VULNERABILITY_ASSESSMENT]", "### [MITIGATION_STRATEGIES]".
           Focus on infrastructure protection and incident response.`
        : activeNode.id === 'threat'
        ? `Act as a dark web threat intelligence operative. Analyze the query for indicators of compromise (IOCs) and threat actor patterns. 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [IOC_ANALYSIS]", "### [ACTOR_PROFILING]", "### [MALWARE_CAMPAIGNS]".
           Provide a high-level technical breakdown.`
        : activeNode.id === 'vuln'
        ? `Act as a CVE/Vulnerability researcher. Provide detailed technical information about vulnerabilities. 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [CVE_DETAILS]", "### [EXPLOITABILITY_ANALYSIS]", "### [REMEDIATION_PLAN]".
           Reference official CVE databases and security advisories.`
        : `Act as a senior cyber intelligence analyst. Provide a detailed, technical, and actionable intelligence report for the following query within the context of ${activeNode.name}: "${searchQuery}". 
           Format your response into distinct sections starting with "### [SECTION_NAME]".
           For example: "### [EXECUTIVE_SUMMARY]", "### [TECHNICAL_ANALYSIS]", "### [RISK_ASSESSMENT]".
           Include potential threats, mitigation strategies, and relevant technical indicators. Use a professional, "hacker-style" markdown format.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: searchQuery,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });

      const reportText = response.text || 'No intelligence data retrieved for this node.';
      setResult(reportText);
      
      // Add to history
      const historyItem: SearchHistoryItem = {
        id: Math.random().toString(36).substr(2, 9),
        query: searchQuery,
        nodeName: activeNode.name,
        timestamp: Date.now(),
        result: reportText,
      };
      setHistory(prev => [historyItem, ...prev].slice(0, 20));

      // Extract grounding sources
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const extractedSources = chunks
          .filter(chunk => chunk.web)
          .map(chunk => ({
            title: chunk.web?.title || 'Source',
            uri: chunk.web?.uri || ''
          }))
          .filter(source => source.uri !== '');
        setSources(extractedSources);
      }
    } catch (err) {
      console.error('Gemini Error:', err);
      setError('Failed to establish secure connection to the intelligence hub.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bevel-card p-4 md:p-8 bg-cyber-glass border border-cyber-border hover:border-red transition-all shadow-[0_0_30px_rgba(255,0,0,0.05)]">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-red/10 rounded-lg">
            <ShieldCheck className="w-8 h-8 text-red" />
          </div>
          <div>
            <h3 className="text-lg md:text-xl font-bold tracking-[0.2em] md:tracking-[0.3em] text-white uppercase">: CYBER-INFO</h3>
            <p className="text-[10px] text-red/60 tracking-widest uppercase mt-1">Unified Multi-Node Intelligence Interface</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full md:w-auto">
          <div className="flex bg-black/40 border border-cyber-border rounded-lg p-1">
            <button 
              onClick={() => setView('SEARCH')}
              className={`flex-1 sm:flex-none px-3 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${view === 'SEARCH' ? 'bg-red text-white' : 'text-red/40 hover:text-red/60'}`}
            >
              <Search className="w-3 h-3" /> Search
            </button>
            <button 
              onClick={() => setView('HISTORY')}
              className={`flex-1 sm:flex-none px-3 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${view === 'HISTORY' ? 'bg-red text-white' : 'text-red/40 hover:text-red/60'}`}
            >
              <History className="w-3 h-3" /> History
            </button>
            <button 
              onClick={() => setView('PROFILE')}
              className={`flex-1 sm:flex-none px-3 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${view === 'PROFILE' ? 'bg-red text-white' : 'text-red/40 hover:text-red/60'}`}
            >
              <User className="w-3 h-3" /> Profile
            </button>
          </div>
          <div className="flex items-center justify-center gap-2 px-4 py-2 bg-red/5 border border-red/20 rounded-full">
            <Zap className="w-3 h-3 text-red animate-pulse" />
            <span className="text-[9px] font-bold text-red uppercase tracking-tighter">System Status: Active</span>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {view === 'SEARCH' && (
          <motion.div
            key="search-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            {/* Node Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-10">
              {INTELLIGENCE_NODES.map((node) => (
                <motion.button
                  key={node.id}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setActiveNode(node);
                    setResult(null);
                    setQuery('');
                  }}
                  className={`bevel-card-sm p-4 border transition-all flex flex-col items-center gap-3 text-center group ${
                    activeNode.id === node.id 
                      ? 'bg-electric-green border-electric-green text-black shadow-[0_0_20px_rgba(114,255,19,0.3)]' 
                      : 'bg-black/40 border-cyber-border text-electric-green/60 hover:border-electric-green/40'
                  }`}
                >
                  <node.icon className={`w-6 h-6 ${activeNode.id === node.id ? 'text-white' : 'text-red group-hover:scale-110 transition-transform'}`} />
                  <div className="flex flex-col">
                    <span className="text-[9px] font-black tracking-tighter uppercase leading-none">{node.name}</span>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Sub-nodes for Cyber Security */}
            {activeNode.id === 'cyber' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {SECURITY_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-red/5 rounded hover:border-red/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-red/40 group-hover:text-red transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for HIBP */}
            {activeNode.id === 'hibp' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {HIBP_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-red/5 rounded hover:border-red/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-red/40 group-hover:text-red transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for Gov Services */}
            {activeNode.id === 'gov' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {GOV_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-red/5 rounded hover:border-red/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-red/40 group-hover:text-red transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for DGFT COO */}
            {activeNode.id === 'dgft' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {DGFT_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-red/5 rounded hover:border-red/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-red/40 group-hover:text-red transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for Open Data India */}
            {activeNode.id === 'data_gov' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {DATA_GOV_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-red/5 rounded hover:border-red/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-red/40 group-hover:text-red transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Unified Search */}
            <div className="relative mb-8 flex flex-col sm:block">
              <div className="absolute left-4 top-[22px] sm:top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none hidden sm:flex">
                <activeNode.icon className="w-4 h-4 text-red/40" />
                <div className="h-4 w-[1px] bg-red/20" />
              </div>
              <form onSubmit={searchHub} className="flex flex-col sm:block">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={`QUERY_${activeNode.name}_NODE...`}
                  className="w-full pl-4 sm:pl-14 pr-4 sm:pr-14 py-4 outline-none font-mono placeholder:text-orange/10 focus:border-orange transition-all bevel-card-sm text-sm mb-3 sm:mb-0 bg-black/60 border border-cyber-border text-orange"
                />
                <button 
                  type="submit"
                  disabled={isLoading}
                  className="sm:absolute sm:right-3 sm:top-1/2 sm:-translate-y-1/2 w-full sm:w-auto p-3 sm:p-2.5 transition-all bevel-card-sm disabled:opacity-50 flex items-center justify-center bg-electric-green text-black hover:shadow-[0_0_15px_rgba(114,255,19,0.5)]"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                </button>
              </form>
            </div>

            {/* Results Area */}
            <AnimatePresence mode="wait">
              {showSearchingState && (
                <motion.div
                  key="searching-state"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="mt-8"
                >
                  <SearchingState />
                </motion.div>
              )}

              {error && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-4 border border-red-500/30 bg-red-500/5 text-red-500 text-xs font-mono mb-6 rounded-lg"
                >
                  {">"} ERROR: {error}
                </motion.div>
              )}

              {result && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bevel-card p-4 md:p-8 relative bg-black/40 border-cyber-border"
                >
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 border-b border-cyber-border pb-6 mb-8">
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5 text-red" />
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-white">INTELLIGENCE_REPORT_DECRYPTED</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center bevel-card-sm p-0.5 bg-red/5 border border-red/20">
                        <button
                          onClick={() => setCurrentLang('EN')}
                          className={`px-3 py-1 text-[10px] font-bold rounded transition-all ${
                            currentLang === 'EN' 
                              ? 'bg-red text-white' 
                              : 'text-red/40 hover:text-red/60'
                          }`}
                        >
                          EN
                        </button>
                        <button
                          onClick={() => translateResult('HI')}
                          disabled={isTranslating}
                          className={`px-3 py-1 text-[10px] font-bold rounded transition-all flex items-center gap-2 ${
                            currentLang === 'HI' 
                              ? 'bg-red text-white' 
                              : 'text-red/40 hover:text-red/60'
                          }`}
                        >
                          {isTranslating ? <Loader2 className="w-3 h-3 animate-spin" /> : 'HI'}
                        </button>
                      </div>
                      <button
                        onClick={downloadPDF}
                        className="flex items-center gap-2 text-[10px] uppercase font-bold px-3 py-1.5 bevel-card-sm border border-red/20 text-red hover:bg-red/10 transition-all"
                      >
                        <Download className="w-3 h-3" /> PDF
                      </button>
                      <button
                        onClick={sendToTelegram}
                        disabled={isSending || !result}
                        className={`flex items-center gap-2 text-[10px] uppercase font-bold px-3 py-1.5 bevel-card-sm border transition-all ${
                          sendSuccess 
                            ? 'bg-red border-red text-white' 
                            : 'bg-red/5 border-red/20 text-red hover:bg-red/10'
                        }`}
                      >
                        {isSending ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : sendSuccess ? (
                          <>SENT <ShieldCheck className="w-3 h-3" /></>
                        ) : (
                          <>SEND_TO_TELEGRAM <Send className="w-3 h-3" /></>
                        )}
                      </button>
                      <a 
                        href={activeNode.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-[10px] text-red/40 hover:text-red transition-colors uppercase font-bold"
                      >
                        Source Portal <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="markdown-body text-sm font-mono leading-relaxed space-y-6 w-full overflow-x-hidden relative z-10 text-white/80">
                    <Markdown>{currentLang === 'HI' ? translatedResult : result}</Markdown>
                  </div>

                  {sources.length > 0 && (
                    <div className="mt-12 pt-8 border-t border-cyber-border">
                      <div className="flex items-center gap-2 mb-6">
                        <BookOpen className="w-4 h-4 text-red/60" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-red/60">Intelligence Sources</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {sources.map((source, idx) => (
                          <a
                            key={idx}
                            href={source.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-4 bevel-card-sm border transition-all flex items-center justify-between group bg-red/5 border-red/10 hover:border-red/30"
                          >
                            <div className="flex flex-col gap-1 overflow-hidden">
                              <span className="text-[10px] font-bold truncate text-white/80">{source.title}</span>
                              <span className="text-[8px] truncate text-red/40">{source.uri}</span>
                            </div>
                            <ExternalLink className="w-3 h-3 text-red/20 group-hover:text-red transition-colors flex-shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {!result && !isLoading && !error && !showSearchingState && (
              <div className="flex flex-col items-center justify-center py-20 text-white/5 font-mono text-xs gap-6 border border-dashed border-red/5 rounded-2xl mt-8">
                <div className="relative">
                  <Lock className="w-12 h-12 opacity-10" />
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border border-dashed border-red/20 rounded-full scale-150"
                  />
                </div>
                <div className="flex flex-col items-center gap-2">
                  <span className="tracking-[0.5em] uppercase">Awaiting Encrypted Query</span>
                  <span className="text-[8px] opacity-50">Select a node and enter parameters to begin retrieval</span>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {view === 'HISTORY' && (
          <motion.div
            key="history-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <History className="w-5 h-5 text-red" />
                <h4 className="text-sm font-bold uppercase tracking-widest text-white">Intelligence Retrieval History</h4>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => {
                    const doc = new jsPDF();
                    doc.setFontSize(20);
                    doc.setTextColor(255, 0, 0);
                    doc.text("CYBER-INFO HISTORY LOG", 10, 20);
                    doc.setFontSize(10);
                    doc.setTextColor(100);
                    doc.text(`Generated: ${new Date().toLocaleString()}`, 10, 30);
                    doc.line(10, 35, 200, 35);
                    
                    let y = 45;
                    history.forEach((item, idx) => {
                      if (y > 270) { doc.addPage(); y = 20; }
                      doc.setTextColor(255, 0, 0);
                      doc.text(`${idx + 1}. NODE: ${item.nodeName} | QUERY: ${item.query}`, 10, y);
                      doc.setTextColor(100);
                      doc.text(`TIME: ${new Date(item.timestamp).toLocaleString()}`, 10, y + 5);
                      y += 15;
                    });
                    doc.save("cyber_info_history.pdf");
                  }}
                  disabled={history.length === 0}
                  className="text-[10px] text-red/60 hover:text-red flex items-center gap-2 uppercase font-bold transition-colors disabled:opacity-30"
                >
                  <Download className="w-3 h-3" /> Export PDF
                </button>
                <button 
                  onClick={() => setHistory([])}
                  className="text-[10px] text-orange/60 hover:text-orange flex items-center gap-2 uppercase font-bold transition-colors"
                >
                  <Trash2 className="w-3 h-3" /> Clear History
                </button>
              </div>
            </div>

            {history.length === 0 ? (
              <div className="py-20 text-center border border-dashed border-red/10 rounded-xl">
                <Clock className="w-8 h-8 text-red/10 mx-auto mb-4" />
                <p className="text-[10px] text-red/20 uppercase tracking-widest">No retrieval logs found in current session</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {history.map((item) => (
                  <div 
                    key={item.id}
                    className="p-4 bg-black/40 border border-cyber-border rounded-xl hover:border-red/30 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="px-2 py-0.5 bg-red/10 border border-red/20 rounded text-[8px] font-bold text-red uppercase">
                          {item.nodeName}
                        </div>
                        <span className="text-xs font-bold text-white/80">{item.query}</span>
                      </div>
                      <span className="text-[8px] text-red/30">{new Date(item.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <button 
                      onClick={() => {
                        setResult(item.result);
                        setView('SEARCH');
                      }}
                      className="text-[9px] text-red/60 hover:text-red uppercase font-bold flex items-center gap-2 transition-colors"
                    >
                      Restore Report
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {view === 'PROFILE' && (
          <motion.div
            key="profile-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-black/40 border border-electric-green/10 rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <User className="w-32 h-32" />
              </div>
              
              <div className="flex items-center gap-6 mb-8 relative z-10">
                <div className="w-20 h-20 rounded-2xl bg-electric-green/10 border border-electric-green/30 flex items-center justify-center overflow-hidden">
                  {(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.photo_url ? (
                    <img src={(window as any).Telegram.WebApp.initDataUnsafe.user.photo_url} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <img 
                      src="https://picsum.photos/seed/smart-haider/400/400" 
                      alt="HAIDER" 
                      className="w-full h-full object-cover grayscale"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>
                <div>
                  <h4 className="text-2xl font-bold text-white tracking-tighter uppercase">
                    {(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.first_name || 'HAIDER'}
                  </h4>
                  <p className="text-xs text-electric-green/60 font-mono">
                    ID: {(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id || '0x' + Math.random().toString(16).substr(2, 8).toUpperCase()}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
                <div className="p-4 bg-electric-green/5 border border-electric-green/10 rounded-xl">
                  <span className="text-[10px] text-electric-green/40 uppercase font-bold block mb-1">Access Level</span>
                  <span className="text-sm text-electric-green font-mono">LEVEL_4_ADMIN</span>
                </div>
                <div className="p-4 bg-electric-green/5 border border-electric-green/10 rounded-xl">
                  <span className="text-[10px] text-electric-green/40 uppercase font-bold block mb-1">Participate Amount</span>
                  <span className="text-sm text-red font-mono">₹{paidAmount}</span>
                </div>
                <div className="p-4 bg-electric-green/5 border border-electric-green/10 rounded-xl">
                  <span className="text-[10px] text-electric-green/40 uppercase font-bold block mb-1">Total Retrievals</span>
                  <span className="text-sm text-white font-mono">{history.length}</span>
                </div>
                <div className="p-4 bg-electric-green/5 border border-electric-green/10 rounded-xl">
                  <span className="text-[10px] text-electric-green/40 uppercase font-bold block mb-1">Node Connection</span>
                  <span className="text-sm text-white font-mono">STABLE</span>
                </div>
              </div>

              <div className="mt-8 flex flex-col gap-4">
                {(window as any).Telegram?.WebApp?.initDataUnsafe?.user && (
                  <div className="p-4 bg-orange/5 border border-orange/20 rounded-xl flex items-center gap-4">
                    <div className="p-2 bg-orange/10 rounded-lg">
                      <Send className="w-5 h-5 text-orange" />
                    </div>
                    <div>
                      <span className="text-[10px] text-orange/60 uppercase font-bold block">Telegram Linked</span>
                      <span className="text-xs text-orange font-mono">@{(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.username || 'N/A'}</span>
                    </div>
                  </div>
                )}

                {onLogout && (
                  <button
                    onClick={onLogout}
                    className="w-full py-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-500 font-bold uppercase tracking-[0.2em] hover:bg-red-500 hover:text-white transition-all flex items-center justify-center gap-3 group"
                  >
                    <Zap className="w-4 h-4 group-hover:animate-pulse" />
                    DISCONNECT_SESSION / LOGOUT
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
