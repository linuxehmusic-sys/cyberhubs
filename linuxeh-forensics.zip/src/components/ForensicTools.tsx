import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, Copy, Check, Loader2, Zap, Globe, Shield, Terminal } from 'lucide-react';
import { SearchingState } from './SearchingState';

export const ForensicTools: React.FC = () => {
  const [url, setUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Debounced loading state
  const [showSearchingState, setShowSearchingState] = useState(false);
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isLoading) {
      timer = setTimeout(() => setShowSearchingState(true), 400);
    } else {
      setShowSearchingState(false);
    }
    return () => clearTimeout(timer);
  }, [isLoading]);

  const shortenUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsLoading(true);
    try {
      // Using TinyURL API (public)
      const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
      if (response.ok) {
        const result = await response.text();
        setShortUrl(result);
      } else {
        throw new Error('Failed to shorten URL');
      }
    } catch (error) {
      console.error('Shortener Error:', error);
      alert('Failed to establish connection with Shortener Node.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shortUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* URL Shortener Tool */}
      <div className="bevel-card p-8 relative overflow-hidden bg-cyber-glass border border-cyber-border">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
          <Link className="w-32 h-32 text-red" />
        </div>

        <div className="flex items-center gap-3 mb-6">
          <Zap className="w-6 h-6 text-red" />
          <h2 className="text-xl font-bold tracking-[0.3em] uppercase text-white">
            : URL_SHORTENER_NODE
          </h2>
        </div>

        <p className="text-xs mb-8 uppercase tracking-widest leading-relaxed text-red/60">
          Generate secure, shortened aliases for long-form intelligence URLs. 
          Bypass character limits and obfuscate destination nodes.
        </p>

        <form onSubmit={shortenUrl} className="space-y-6">
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-red/40">
              <Globe className="w-5 h-5" />
            </div>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="ENTER_LONG_FORM_URL..."
              required
              className="w-full pl-12 pr-4 py-4 outline-none font-mono placeholder:text-orange/10 focus:border-orange transition-all bevel-card-sm text-sm bg-black/60 border border-cyber-border text-orange"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 font-bold uppercase tracking-[0.2em] bevel-card-sm transition-all disabled:opacity-50 flex items-center justify-center gap-3 bg-electric-green text-black hover:shadow-[0_0_20px_rgba(114,255,19,0.5)]"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
            {isLoading ? 'GENERATING_ALIAS...' : 'INITIALIZE_SHORTENING'}
          </button>
        </form>

        <AnimatePresence>
          {showSearchingState && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="mt-8"
            >
              <SearchingState />
            </motion.div>
          )}
        </AnimatePresence>

        {shortUrl && !showSearchingState && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 bevel-card-sm flex flex-col md:flex-row items-center justify-between gap-4 bg-black/40 border border-red/30"
          >
            <div className="flex items-center gap-3 overflow-hidden w-full">
              <div className="p-2 bevel-card-sm bg-red/10">
                <Terminal className="w-4 h-4 text-red" />
              </div>
              <span className="text-sm font-mono text-white truncate">{shortUrl}</span>
            </div>
            <button
              onClick={copyToClipboard}
              className={`flex items-center gap-2 px-6 py-2 bevel-card-sm font-bold uppercase text-[10px] tracking-widest transition-all whitespace-nowrap ${
                copied 
                  ? 'bg-red text-white' 
                  : 'bg-red/10 text-red border border-red/30 hover:bg-red hover:text-white'
              }`}
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? 'COPIED' : 'COPY_ALIAS'}
            </button>
          </motion.div>
        )}
      </div>

      {/* Other Forensic Tools Placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bevel-card bg-cyber-glass border border-cyber-border p-6 opacity-50 grayscale hover:grayscale-0 transition-all cursor-not-allowed group">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5 text-red/40 group-hover:text-red" />
            <span className="text-xs font-bold uppercase tracking-widest text-white/60">Metadata_Extractor</span>
          </div>
          <div className="h-24 border border-dashed border-red/10 rounded-xl flex items-center justify-center">
            <span className="text-[8px] uppercase tracking-[0.5em] text-red/30">Node_Offline</span>
          </div>
        </div>
        <div className="bevel-card bg-cyber-glass border border-cyber-border p-6 opacity-50 grayscale hover:grayscale-0 transition-all cursor-not-allowed group">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-red/40 group-hover:text-red" />
            <span className="text-xs font-bold uppercase tracking-widest text-white/60">IP_Geolocator</span>
          </div>
          <div className="h-24 border border-dashed border-red/10 rounded-xl flex items-center justify-center">
            <span className="text-[8px] uppercase tracking-[0.5em] text-red/30">Node_Offline</span>
          </div>
        </div>
      </div>
    </div>
  );
};
