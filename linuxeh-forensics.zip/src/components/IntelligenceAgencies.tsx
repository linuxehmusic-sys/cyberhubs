import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  Search, 
  Loader2, 
  Globe, 
  Lock, 
  Target, 
  FileText, 
  ExternalLink, 
  Zap,
  ChevronRight,
  Shield,
  Activity,
  Download,
  Languages,
  History,
  Trash2,
  Clock
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import Markdown from 'react-markdown';
import { jsPDF } from "jspdf";
import { SearchingState } from './SearchingState';

const AGENCY_NODES = [
  { name: 'CIA', country: 'USA', domain: 'cia.gov' },
  { name: 'Mossad', country: 'Israel', domain: 'mossad.gov.il' },
  { name: 'MI6', country: 'UK', domain: 'sis.gov.uk' },
  { name: 'FSB', country: 'Russia', domain: 'fsb.ru' },
  { name: 'BND', country: 'Germany', domain: 'bnd.bund.de' },
  { name: 'ASIS', country: 'Australia', domain: 'asis.gov.au' },
  { name: 'DGSE', country: 'France', domain: 'dgse.gouv.fr' },
  { name: 'FBI', country: 'USA', domain: 'fbi.gov' },
  { name: 'NIA', country: 'India', domain: 'nia.gov.in' },
  { name: 'CBI', country: 'India', domain: 'cbi.gov.in' },
  { name: 'ED', country: 'India', domain: 'enforcementdirectorate.gov.in' },
];

interface IntelHistoryItem {
  id: string;
  query: string;
  timestamp: number;
  result: string;
}

export const IntelligenceAgencies: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [dossier, setDossier] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sources, setSources] = useState<{ title: string; uri: string }[]>([]);
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [currentLang, setCurrentLang] = useState<'EN' | 'HI'>('EN');
  const [translatedDossier, setTranslatedDossier] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [history, setHistory] = useState<IntelHistoryItem[]>([]);
  const [view, setView] = useState<'SEARCH' | 'HISTORY'>('SEARCH');

  // Debounced loading state
  const [showSearchingState, setShowSearchingState] = useState(false);
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isLoading) {
      timer = setTimeout(() => setShowSearchingState(true), 400);
    } else {
      setShowSearchingState(false);
    }
    return () => clearTimeout(timer);
  }, [isLoading]);

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  const downloadPDF = () => {
    const doc = new jsPDF();
    const content = currentLang === 'HI' ? translatedDossier : dossier;
    
    if (!content) return;

    doc.setFontSize(20);
    doc.setTextColor(114, 255, 19); // Electric Green
    doc.text("INTELLIGENCE DOSSIER REPORT", 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(255, 0, 0); // Red
    doc.text(`Classification: TOP SECRET`, 10, 30);
    doc.text(`Date: ${new Date().toLocaleString()}`, 10, 35);
    
    doc.setDrawColor(114, 255, 19);
    doc.line(10, 40, 200, 40);

    doc.setFontSize(12);
    doc.setTextColor(255, 0, 0); // Red
    const splitText = doc.splitTextToSize(content.replace(/[#*`]/g, ''), 180);
    doc.text(splitText, 10, 50);

    doc.save(`intel_dossier_${Date.now()}.pdf`);
  };

  const translateDossier = async () => {
    if (!dossier || currentLang === 'HI') return;
    setIsTranslating(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Translate the following intelligence dossier into Hindi. Keep technical terms like "CIA", "Mossad", "Espionage", "Counter-intelligence" in English but written in Hindi script if appropriate, or keep them in English. Ensure the tone is professional, authoritative, and fits a classified document style: \n\n${dossier}`,
      });
      setTranslatedDossier(response.text || 'Translation failed.');
      setCurrentLang('HI');
    } catch (err) {
      console.error('Translation Error:', err);
      setError('TRANSLATION_NODE_FAILURE');
    } finally {
      setIsTranslating(false);
    }
  };

  const runInvestigation = async (e?: React.FormEvent | string) => {
    if (e && typeof e !== 'string') e.preventDefault();
    const searchQuery = typeof e === 'string' ? e : query;
    
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    setError(null);
    setDossier(null);
    setSources([]);

    try {
      const systemInstruction = `
        Act as a Senior Intelligence Analyst specializing in global espionage and national security agencies.
        Provide a detailed "Intelligence Dossier" for the following query: "${searchQuery}".
        Focus on organizational structure, known operations, mandates, and recent public activities.
        Use a highly professional, classified-document style with headers like [CLASSIFIED], [OPERATIONAL_HISTORY], and [MANDATE].
        Format the output in a clean, terminal-style markdown.
        Always include a disclaimer that this information is based on public records.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: searchQuery,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });

      const reportText = response.text || 'NO_DATA_RETRIEVED_FROM_SECURE_CHANNELS';
      setDossier(reportText);

      // Add to history
      const historyItem: IntelHistoryItem = {
        id: Math.random().toString(36).substr(2, 9),
        query: searchQuery,
        timestamp: Date.now(),
        result: reportText,
      };
      setHistory(prev => [historyItem, ...prev].slice(0, 10));

      // Extract grounding sources
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const extractedSources = chunks
          .filter(chunk => chunk.web)
          .map(chunk => ({
            title: chunk.web?.title || 'INTEL_SOURCE',
            uri: chunk.web?.uri || ''
          }))
          .filter(source => source.uri !== '');
        setSources(extractedSources);
      }
    } catch (err) {
      console.error('Investigation Error:', err);
      setError('SECURE_CHANNEL_INTERRUPTED: FAILED_TO_RETRIEVE_INTEL');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mb-12">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-6">
        <div className="flex items-center gap-3">
          <ShieldAlert className="w-6 h-6 animate-pulse text-red" />
          <h2 className="text-lg md:text-xl font-bold tracking-[0.2em] md:tracking-[0.3em] uppercase text-white">
            : INVESTIGATION
          </h2>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full md:w-auto">
          <div className="flex rounded-lg p-1 bg-black/40 border border-cyber-border">
            <button 
              onClick={() => setView('SEARCH')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                view === 'SEARCH' 
                  ? 'bg-electric-green text-black' 
                  : 'text-electric-green/40 hover:text-electric-green/60'
              }`}
            >
              <Search className="w-3 h-3" /> Search
            </button>
            <button 
              onClick={() => setView('HISTORY')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                view === 'HISTORY' 
                  ? 'bg-electric-green text-black' 
                  : 'text-electric-green/40 hover:text-electric-green/60'
              }`}
            >
              <History className="w-3 h-3" /> History
            </button>
          </div>
          <div className="flex items-center justify-center gap-2 px-3 py-2 rounded text-[10px] font-bold uppercase tracking-widest bg-electric-green/10 border border-electric-green/30 text-electric-green">
            <Activity className="w-3 h-3" /> LIVE_INTEL_FEED
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {view === 'SEARCH' ? (
          <motion.div
            key="search-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <div className="bevel-card p-6 mb-8 bg-cyber-glass border-cyber-border">
        <div className="flex flex-wrap gap-2 mb-6">
          {AGENCY_NODES.map((node) => (
            <button
              key={node.name}
              onClick={() => {
                setActiveNode(node.name);
                setQuery(`Detailed dossier on ${node.name} (${node.country})`);
                runInvestigation(`Detailed dossier on ${node.name} (${node.country})`);
              }}
              className={`flex-1 min-w-[100px] sm:flex-none px-3 py-2.5 bevel-card-sm border text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                activeNode === node.name 
                  ? 'bg-electric-green text-black border-electric-green shadow-[0_0_10px_rgba(114,255,19,0.3)]' 
                  : 'bg-black/40 border-cyber-border text-electric-green/60 hover:border-electric-green/40 hover:text-electric-green'
              }`}
            >
              <Target className="w-3 h-3" /> {node.name}
            </button>
          ))}
        </div>

        <form onSubmit={runInvestigation} className="relative flex flex-col sm:block">
          <div className="absolute left-4 top-[22px] sm:top-1/2 -translate-y-1/2 hidden sm:block text-red/40">
            <Search className="w-5 h-5" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ENTER_QUERY..."
            className="w-full pl-4 sm:pl-12 pr-4 sm:pr-36 py-4 outline-none font-mono placeholder:text-orange/10 focus:border-orange transition-all bevel-card-sm text-sm mb-3 sm:mb-0 bg-black/60 border border-cyber-border text-orange"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="sm:absolute sm:right-2 sm:top-1/2 sm:-translate-y-1/2 w-full sm:w-auto px-6 py-3 sm:py-2 font-bold uppercase tracking-widest text-[10px] bevel-card-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2 bg-electric-green text-black hover:shadow-[0_0_15px_rgba(114,255,19,0.5)]"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            {isLoading ? 'INVESTIGATING...' : 'RUN_QUERY'}
          </button>
        </form>
      </div>

      <AnimatePresence mode="wait">
        {showSearchingState && (
          <motion.div
            key="searching-state"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="mt-8"
          >
            <SearchingState />
          </motion.div>
        )}

        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 border border-red-500/30 bg-red-500/5 text-red-500 text-xs font-mono mb-6 rounded-lg uppercase tracking-widest"
          >
            {">"} ERROR: {error}
          </motion.div>
        )}

        {dossier && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bevel-card p-4 md:p-8 relative bg-black/40 border-cyber-border"
          >
            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
              <Shield className="w-48 h-48 text-red" />
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 border-b border-cyber-border pb-4 gap-4">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-red" />
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-white">INTELLIGENCE_DOSSIER_DECRYPTED</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center bevel-card-sm p-0.5 bg-red/5 border border-red/20">
                  <button
                    onClick={() => setCurrentLang('EN')}
                    className={`px-3 py-1 text-[10px] font-bold rounded transition-all ${
                      currentLang === 'EN' 
                        ? 'bg-red text-white' 
                        : 'text-red/40 hover:text-red/60'
                    }`}
                  >
                    EN
                  </button>
                  <button
                    onClick={translateDossier}
                    disabled={isTranslating}
                    className={`px-3 py-1 text-[10px] font-bold rounded transition-all flex items-center gap-2 ${
                      currentLang === 'HI' 
                        ? 'bg-red text-white' 
                        : 'text-red/40 hover:text-red/60'
                    }`}
                  >
                    {isTranslating ? <Loader2 className="w-3 h-3 animate-spin" /> : 'HI'}
                  </button>
                </div>
                <button
                  onClick={downloadPDF}
                  className="flex items-center gap-2 text-[10px] uppercase font-bold px-3 py-1.5 bevel-card-sm border border-red/20 text-red hover:bg-red/10 transition-all"
                >
                  <Download className="w-3 h-3" /> PDF
                </button>
              </div>
            </div>

            <div className="markdown-body text-sm font-mono leading-relaxed space-y-4 relative z-10 w-full overflow-x-hidden text-white/80">
              <Markdown>{currentLang === 'HI' ? translatedDossier : dossier}</Markdown>
            </div>

            {sources.length > 0 && (
              <div className="mt-8 pt-6 border-t border-cyber-border">
                <div className="flex items-center gap-2 mb-4">
                  <Globe className="w-4 h-4 text-red/60" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-red/60">VERIFIED_INTEL_SOURCES</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {sources.map((source, idx) => (
                    <a
                      key={idx}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bevel-card-sm border transition-all flex items-center justify-between group bg-red/5 border-red/10 hover:border-red/30"
                    >
                      <div className="flex flex-col gap-1 overflow-hidden">
                        <span className="text-[10px] font-bold truncate text-white/80">{source.title}</span>
                        <span className="text-[8px] truncate text-red/40">{source.uri}</span>
                      </div>
                      <ExternalLink className="w-3 h-3 text-red/20 group-hover:text-red transition-colors flex-shrink-0" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {!dossier && !isLoading && !error && !showSearchingState && (
          <div className="flex flex-col items-center justify-center py-20 text-white/5 font-mono text-xs gap-6 border border-dashed border-red/5 rounded-2xl">
            <div className="relative">
              <Lock className="w-12 h-12 opacity-10" />
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 border border-dashed border-red/20 rounded-full scale-150"
              />
            </div>
            <div className="flex flex-col items-center gap-2">
              <span className="tracking-[0.5em] uppercase">Awaiting Investigation Parameters</span>
              <span className="text-[8px] opacity-50">Select a node or enter a custom agency query to begin decryption</span>
            </div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  ) : (
    <motion.div
        key="history-view"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 20 }}
        className="space-y-4"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <History className="w-5 h-5 text-red" />
            <h4 className="text-sm font-bold uppercase tracking-widest text-white">Investigation Retrieval History</h4>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => {
                const doc = new jsPDF();
                doc.setFontSize(20);
                doc.setTextColor(255, 0, 0);
                doc.text("INVESTIGATION HISTORY LOG", 10, 20);
                doc.setFontSize(10);
                doc.setTextColor(100);
                doc.text(`Generated: ${new Date().toLocaleString()}`, 10, 30);
                doc.line(10, 35, 200, 35);
                
                let y = 45;
                history.forEach((item, idx) => {
                  if (y > 270) { doc.addPage(); y = 20; }
                  doc.setTextColor(255, 0, 0);
                  doc.text(`${idx + 1}. QUERY: ${item.query}`, 10, y);
                  doc.setTextColor(100);
                  doc.text(`TIME: ${new Date(item.timestamp).toLocaleString()}`, 10, y + 5);
                  y += 15;
                });
                doc.save("investigation_history.pdf");
              }}
              disabled={history.length === 0}
              className="text-[10px] text-red/60 hover:text-red flex items-center gap-2 uppercase font-bold transition-colors disabled:opacity-30"
            >
              <Download className="w-3 h-3" /> Export PDF
            </button>
            <button 
              onClick={() => setHistory([])}
              className="text-[10px] text-orange/60 hover:text-orange flex items-center gap-2 uppercase font-bold transition-colors"
            >
              <Trash2 className="w-3 h-3" /> Clear History
            </button>
          </div>
        </div>

        {history.length === 0 ? (
          <div className="py-20 text-center border border-dashed border-red/10 rounded-xl">
            <Clock className="w-8 h-8 text-red/10 mx-auto mb-4" />
            <p className="text-[10px] text-red/20 uppercase tracking-widest">No investigation logs found in current session</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {history.map((item) => (
              <div 
                key={item.id}
                className="p-4 bg-black/40 border border-cyber-border rounded-xl hover:border-red/30 transition-all group"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="px-2 py-0.5 bg-red/10 border border-red/20 rounded text-[8px] font-bold text-red uppercase">
                      INTEL_LOG
                    </div>
                    <span className="text-xs font-bold text-white/80">{item.query}</span>
                  </div>
                  <span className="text-[8px] text-red/30">{new Date(item.timestamp).toLocaleTimeString()}</span>
                </div>
                <button 
                  onClick={() => {
                    setDossier(item.result);
                    setView('SEARCH');
                  }}
                  className="text-[9px] text-red/60 hover:text-red uppercase font-bold flex items-center gap-2 transition-colors"
                >
                  Restore Dossier
                </button>
              </div>
            ))}
          </div>
        )}
      </motion.div>
    )}
  </AnimatePresence>

      <div className="mt-8 p-4 border border-red-500/30 bg-red-500/5 rounded text-[10px] text-red-400/70 tracking-widest uppercase flex items-center gap-3">
        <ShieldAlert className="w-4 h-4 flex-shrink-0" />
        <span>WARNING: ALL QUERIES ARE LOGGED ON THE SECURE NETWORK. UNAUTHORIZED DISSEMINATION OF RETRIEVED INTELLIGENCE IS STRICTLY PROHIBITED.</span>
      </div>
    </div>
  );
};
