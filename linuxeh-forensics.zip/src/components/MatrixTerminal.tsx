import React, { useState, useEffect } from 'react';

interface MatrixTerminalProps {
  text: string;
}

export const MatrixTerminal: React.FC<MatrixTerminalProps> = ({ text }) => {
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayedText((prev) => prev + text.charAt(i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 20);
    return () => clearInterval(interval);
  }, [text]);

  return (
    <div className="bg-black/80 border border-cyber-border p-4 bevel-card-sm font-mono text-xs text-red/80 shadow-[0_0_20px_rgba(0,0,0,0.5)] overflow-hidden whitespace-pre-wrap">
      <div className="flex items-center gap-2 mb-2 border-b border-red/10 pb-2">
        <div className="w-2 h-2 rounded-full bg-red/50" />
        <div className="w-2 h-2 rounded-full bg-orange/50" />
        <div className="w-2 h-2 rounded-full bg-electric-green/50" />
        <span className="ml-2 opacity-30 text-[8px] uppercase tracking-widest">Terminal_v4.0.1</span>
      </div>
      {displayedText}
      <span className="animate-pulse ml-1 inline-block w-1.5 h-3 bg-red/50" />
    </div>
  );
};
