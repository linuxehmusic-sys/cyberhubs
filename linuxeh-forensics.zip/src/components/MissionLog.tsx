import React from 'react';
import { FileText, Clock, ChevronRight } from 'lucide-react';

export const MissionLog: React.FC = () => {
  const logs = [
    { id: 1, time: '2 MIN AGO', action: 'DATABASE_QUERY', target: 'CIA_ARCHIVES', status: 'SUCCESS' },
    { id: 2, time: '15 MIN AGO', action: 'SIGINT_INTERCEPT', target: 'FSB_NODE_09', status: 'ENCRYPTED' },
    { id: 3, time: '1 HOUR AGO', action: 'GEO_LOCATION', target: 'MOSSAD_OPERATIVE', status: 'LOCKED' },
    { id: 4, time: '3 HOURS AGO', action: 'BYPASS_FIREWALL', target: 'MI6_GATEWAY', status: 'SUCCESS' },
  ];

  return (
    <div className="bevel-card p-6 bg-cyber-glass border border-cyber-border">
      <h3 className="text-sm font-bold mb-6 flex items-center gap-2 text-red">
        <FileText className="w-4 h-4 text-electric-green" /> MISSION_LOGS
      </h3>
      
      <div className="space-y-4">
        {logs.map((log) => (
          <div key={log.id} className="group flex items-center justify-between p-3 bevel-card-sm bg-black/20 border border-white/5 hover:border-electric-green/30 transition-all cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="p-2 bevel-card-sm bg-electric-green/5 text-electric-green/40 group-hover:text-electric-green transition-colors">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-red uppercase tracking-widest">{log.action}</span>
                  <span className="text-[8px] text-electric-green/40 font-mono">{log.time}</span>
                </div>
                <p className="text-[9px] text-red/60 tracking-tighter mt-0.5">{log.target}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-[8px] font-bold px-2 py-0.5 rounded-full border ${
                log.status === 'SUCCESS' ? 'border-electric-green/30 text-electric-green bg-electric-green/5' : 'border-orange/30 text-orange bg-orange/5'
              }`}>
                {log.status}
              </span>
              <ChevronRight className="w-3 h-3 text-white/10 group-hover:text-electric-green transition-colors" />
            </div>
          </div>
        ))}
      </div>
      
      <button className="w-full mt-6 py-3 text-[10px] font-bold uppercase tracking-[0.3em] text-electric-green/40 hover:text-electric-green transition-colors border border-dashed border-electric-green/10 bevel-card-sm hover:border-electric-green/30">
        View All Archives
      </button>
    </div>
  );
};
