import React from 'react';
import { Search } from 'lucide-react';
import { motion } from 'motion/react';

interface SearchingStateProps {
  isVisible?: boolean;
}

export const SearchingState: React.FC<SearchingStateProps> = ({ isVisible = true }) => {
  if (!isVisible) return null;

  return (
    <div className="flex items-center justify-center p-8 w-full max-w-sm mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="w-full glass-card p-10 flex flex-col items-center text-center relative overflow-hidden searching-scan"
        style={{ borderRadius: '20px' }}
      >
        {/* 3D Magnifying Glass Icon */}
        <div className="relative mb-8">
          <motion.div
            animate={{ 
              y: [0, -10, 0],
              rotate: [0, 5, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="relative z-10 animate-pulse-glow"
          >
            <Search 
              size={80} 
              className="text-red drop-shadow-[0_0_15px_rgba(255,0,0,0.5)]" 
              strokeWidth={1.5}
            />
            {/* Inner glass effect for the icon */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent rounded-full blur-[1px] pointer-events-none" />
          </motion.div>
          
          {/* Shadow below the floating icon */}
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.2, 0.1, 0.2]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-12 h-2 bg-black/20 blur-md rounded-full"
          />
        </div>

        {/* Skeleton Shimmer Bars */}
        <div className="w-full space-y-4">
          {/* Thick Title Bar */}
          <div className="h-6 w-3/4 mx-auto rounded-lg overflow-hidden relative bg-orange/5 border border-orange/10">
            <div className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-orange/10 to-transparent bg-[length:200%_100%]" />
          </div>
          
          {/* Thin Description Bars */}
          <div className="space-y-2">
            <div className="h-3 w-full rounded-md overflow-hidden relative bg-orange/5 border border-orange/10">
              <div className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-orange/10 to-transparent bg-[length:200%_100%]" />
            </div>
            <div className="h-3 w-5/6 mx-auto rounded-md overflow-hidden relative bg-orange/5 border border-orange/10">
              <div className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-orange/10 to-transparent bg-[length:200%_100%]" />
            </div>
          </div>
        </div>

        <div className="mt-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-red/40 animate-pulse">
            Processing Data Streams...
          </p>
        </div>

        {/* Subtle glass highlight */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red/50 to-transparent opacity-30" />
      </motion.div>
    </div>
  );
};

/**
 * Debounced Loading Hook Example
 * 
 * const useDebouncedLoading = (isLoading: boolean, delay = 300) => {
 *   const [showLoading, setShowLoading] = React.useState(false);
 *   
 *   React.useEffect(() => {
 *     let timer: NodeJS.Timeout;
 *     if (isLoading) {
 *       timer = setTimeout(() => setShowLoading(true), delay);
 *     } else {
 *       setShowLoading(false);
 *     }
 *     return () => clearTimeout(timer);
 *   }, [isLoading, delay]);
 *   
 *   return showLoading;
 * };
 */
