import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, 
  Shield, 
  Activity, 
  Lock, 
  Globe,
  Search,
  MessageSquare,
  User
} from 'lucide-react';
import { MatrixBackground } from './components/MatrixBackground';
import { CyberSecurityHub } from './components/CyberSecurityHub';
import { PaymentGate } from './components/PaymentGate';

const TypingText: React.FC<{ text: string }> = ({ text }) => {
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayedText((prev) => prev + text.charAt(i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 50);
    return () => clearInterval(interval);
  }, [text]);

  return <span>{displayedText}</span>;
};

export default function App() {
  const [isLocked, setIsLocked] = useState(true);
  const [isPaid, setIsPaid] = useState(false);
  const [password, setPassword] = useState('');
  const [progress, setProgress] = useState(0);
  const [isExploiting, setIsExploiting] = useState(false);
  const [isGlitching, setIsGlitching] = useState(false);
  const [status, setStatus] = useState('AWAITING CREDENTIALS...');
  const [tgUser, setTgUser] = useState<any>(null);

  useEffect(() => {
    // @ts-ignore
    if (window.Telegram?.WebApp) {
      // @ts-ignore
      const tg = window.Telegram.WebApp;
      tg.ready();
      tg.expand();
      if (tg.initDataUnsafe?.user) {
        setTgUser(tg.initDataUnsafe.user);
      }
    }
  }, []);

  const handleExploit = () => {
    if (password !== '25021991') {
      setStatus('ACCESS DENIED: INVALID_KEY');
      setPassword('');
      return;
    }

    setIsExploiting(true);
    setStatus('BYPASSING_FIREWALL...');
    
    let currentProgress = 0;
    const interval = setInterval(() => {
      if (currentProgress >= 100) {
        clearInterval(interval);
        setIsLocked(false);
      } else {
        currentProgress += Math.random() * 15;
        setProgress(Math.min(currentProgress, 100));
      }
    }, 100);
  };

  const triggerGlitch = () => {
    setIsGlitching(true);
    setTimeout(() => setIsGlitching(false), 1500);
  };

  return (
    <div className={`min-h-screen selection:bg-neon selection:text-black ${isGlitching ? 'glitch' : ''}`}>
      <MatrixBackground />
      <div className="scanlines" />

      <AnimatePresence mode="wait">
        {isLocked ? (
          <motion.div
            key="login"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-hacker-bg/98"
          >
            <div className="w-full max-w-md p-8 border rounded-lg bg-hacker-glass border-neon shadow-[0_0_15px_rgba(159,239,0,0.4)] text-center">
              <div className="flex justify-center mb-6">
                <Lock className="w-12 h-12 text-neon" />
              </div>
              <h2 className="text-2xl font-bold mb-2 tracking-tighter text-white">
                {">"} SYSTEM_LOGIN
              </h2>
              <p className="text-xs mb-6 text-neon/70 uppercase tracking-widest">
                {status}
              </p>
              
              <div className="relative mb-6">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="ENTER_ENCRYPTION_KEY"
                  className="w-full p-3 bg-black/50 border border-neon text-neon outline-none font-mono placeholder:text-neon/30 focus:shadow-[0_0_10px_rgba(159,239,0,0.3)] transition-all"
                  onKeyDown={(e) => e.key === 'Enter' && handleExploit()}
                />
              </div>

              {isExploiting && (
                <div className="w-full h-2 bg-hacker-bg rounded-full overflow-hidden mb-6">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className="h-full bg-neon shadow-[0_0_10px_rgba(159,239,0,0.6)]"
                  />
                </div>
              )}

              <button
                onClick={handleExploit}
                disabled={isExploiting}
                className="w-full py-3 border border-neon text-neon font-bold uppercase tracking-widest hover:bg-neon hover:text-black transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
              >
                {isExploiting ? 'EXPLOITING...' : 'INITIALIZE EXPLOIT'}
              </button>
            </div>
          </motion.div>
        ) : !isPaid ? (
          <PaymentGate 
            upiId="hackerstatuss@okaxis" 
            onPaymentSuccess={() => setIsPaid(true)} 
          />
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-20"
          >
            {/* Navbar */}
            <nav className="flex items-center justify-between px-10 py-4 bg-hacker-bg/90 border-b border-neon/30 sticky top-0 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <Terminal className="text-neon" />
                <span className="font-bold text-lg tracking-tighter shadow-neon">
                  TERMINAL_PRO // v2.0
                </span>
              </div>
              <div className="hidden md:flex items-center gap-6 text-[10px] tracking-widest text-neon/60">
                <div className="flex items-center gap-2">
                  <Globe className="w-3 h-3" />
                  [ IP: 192.168.1.1 ]
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-3 h-3" />
                  [ NODE: ACTIVE ]
                </div>
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-3 h-3 text-blue-400" />
                  [ BOT: ONLINE ]
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-3 h-3 text-neon" />
                  [ SECURE ]
                </div>
                {tgUser && (
                  <div className="flex items-center gap-2 px-2 py-0.5 bg-blue-500/10 border border-blue-500/30 rounded text-blue-400">
                    <User className="w-3 h-3" />
                    [ TG: {tgUser.first_name.toUpperCase()} ]
                  </div>
                )}
              </div>
            </nav>

            {/* Main Content */}
            <main className="p-10 max-w-7xl mx-auto">
              {/* Cyber Intelligence Hub */}
              <div className="mb-12">
                <CyberSecurityHub />
              </div>
            </main>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
