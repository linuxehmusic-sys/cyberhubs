import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Loader2, 
  Target, 
  ExternalLink, 
  BookOpen, 
  Lock, 
  Zap, 
  Send,
  History,
  Download,
  User,
  Trash2,
  Clock,
  ArrowRight,
  ShieldAlert,
  FileText,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import Markdown from 'react-markdown';
import { jsPDF } from "jspdf";
import "jspdf-autotable";

// Intelligence Nodes Configuration
const INTELLIGENCE_NODES = [
  { id: 'cyber', name: 'Cyber Security', icon: ShieldCheck, url: 'https://www.cisa.gov' },
  { id: 'threat', name: 'Threat Intel', icon: Target, url: 'https://www.threatintel.com' },
  { id: 'osint', name: 'OSINT Hub', icon: Search, url: 'https://osintframework.com' },
  { id: 'hibp', name: 'HIBP_CHECK', icon: ShieldAlert, url: 'https://haveibeenpwned.com' },
  { id: 'gov', name: 'Gov Services', icon: FileText, url: 'https://serviceonline.gov.in/userCertificate.html' },
  { id: 'dgft', name: 'DGFT COO', icon: Globe, url: 'https://coo.dgft.gov.in/' },
  { id: 'vuln', name: 'Vulnerability', icon: Lock, url: 'https://cve.mitre.org' },
];

const SECURITY_SUB_NODES = [
  { name: 'Malware Analysis' },
  { name: 'Phishing Detection' },
  { name: 'Ransomware Tracking' },
  { name: 'Zero-Day Alerts' },
  { name: 'APT Monitoring' },
  { name: 'Cloud Security' },
  { name: 'IoT Vulnerabilities' },
];

const HIBP_SUB_NODES = [
  { name: 'Check Account Breaches' },
  { name: 'Check Account Pastes' },
  { name: 'Check Password Strength' },
  { name: 'Latest Data Breaches' },
];

const GOV_SUB_NODES = [
  { name: 'Track Application' },
  { name: 'Download Certificate' },
  { name: 'Check Caste Certificate' },
  { name: 'Income Certificate Status' },
  { name: 'Birth/Death Certificate' },
  { name: 'Residence Certificate' },
];

const DGFT_SUB_NODES = [
  { name: 'Apply for COO' },
  { name: 'Verify Certificate' },
  { name: 'Exporter Registration' },
  { name: 'Track COO Status' },
  { name: 'DGFT Helpdesk' },
  { name: 'Trade Notices' },
];

interface SearchHistoryItem {
  id: string;
  query: string;
  nodeName: string;
  timestamp: number;
  result: string;
}

export const CyberSecurityHub: React.FC = () => {
  const [activeNode, setActiveNode] = useState(INTELLIGENCE_NODES[0]);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sources, setSources] = useState<{ title: string; uri: string }[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [currentLang, setCurrentLang] = useState<'EN' | 'HI'>('EN');
  const [translatedResult, setTranslatedResult] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [view, setView] = useState<'SEARCH' | 'HISTORY' | 'PROFILE'>('SEARCH');
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);

  // Initialize Gemini
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  const downloadPDF = () => {
    const doc = new jsPDF();
    const content = currentLang === 'HI' ? translatedResult : result;
    
    if (!content) return;

    doc.setFontSize(20);
    doc.setTextColor(159, 239, 0); // Neon Green
    doc.text("CYBER-INFO INTELLIGENCE REPORT", 10, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Node: ${activeNode.name}`, 10, 30);
    doc.text(`Date: ${new Date().toLocaleString()}`, 10, 35);
    
    doc.setDrawColor(159, 239, 0);
    doc.line(10, 40, 200, 40);

    doc.setFontSize(12);
    doc.setTextColor(0);
    const splitText = doc.splitTextToSize(content.replace(/[#*`]/g, ''), 180);
    doc.text(splitText, 10, 50);

    doc.save(`cyber_intel_${Date.now()}.pdf`);
  };

  const translateResult = async (targetLang: 'HI') => {
    if (!result) return;
    setIsTranslating(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Translate the following technical cyber security report into Hindi. Keep technical terms like "Malware", "Phishing", "Firewall" in English but written in Hindi script if appropriate, or keep them in English. Ensure the tone is professional and authoritative: \n\n${result}`,
      });
      setTranslatedResult(response.text || 'Translation failed.');
      setCurrentLang('HI');
    } catch (err) {
      console.error('Translation Error:', err);
      setError('Translation node failed to respond.');
    } finally {
      setIsTranslating(false);
    }
  };

  const sendToTelegram = async () => {
    if (!result) return;
    setIsSending(true);
    try {
      const botToken = '8206372673:AAEK0l594tMkLSNPGsLB0KzrdtWzO6MU1zE';
      const chatId = (window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id;
      
      if (!chatId) {
        setError('Telegram session not detected. Please open in Telegram.');
        return;
      }

      const message = `🛡 *CYBER-INFO INTELLIGENCE REPORT*\n\n*Node:* ${activeNode.name}\n*Query:* ${query}\n\n${result.substring(0, 3500)}...`;

      const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      });

      if (response.ok) {
        setSendSuccess(true);
        setTimeout(() => setSendSuccess(false), 3000);
      } else {
        throw new Error('Failed to transmit data');
      }
    } catch (err) {
      setError('Failed to transmit intelligence to Telegram node.');
    } finally {
      setIsSending(false);
    }
  };

  const searchHub = async (e?: React.FormEvent | string) => {
    if (e && typeof e !== 'string') e.preventDefault();
    const searchQuery = typeof e === 'string' ? e : query;
    
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);
    setSources([]);
    setTranslatedResult(null);
    setCurrentLang('EN');

    try {
      // Special handling for HIBP node
      if (activeNode.id === 'hibp') {
        const hibpKey = process.env.HIBP_API_KEY;
        
        // If it's a password check, we don't need a key
        if (searchQuery.toLowerCase().includes('password')) {
          const password = searchQuery.split(' ').pop() || '';
          if (password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-1', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
            
            const prefix = hashHex.substring(0, 5);
            const suffix = hashHex.substring(5);
            
            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            const text = await response.text();
            const lines = text.split('\n');
            const match = lines.find(line => line.startsWith(suffix));
            
            if (match) {
              const count = match.split(':')[1];
              setResult(`### ⚠️ PWNED_PASSWORD_DETECTED\n\nThis password has been seen **${count.trim()}** times in data breaches. \n\n**Recommendation:** Change this password immediately and use a unique, complex password for every account.`);
            } else {
              setResult(`### ✅ PASSWORD_SECURE\n\nThis password was not found in any known data breaches. \n\n**Note:** This doesn't mean it's "safe", just that it hasn't been leaked yet.`);
            }
            setIsLoading(false);
            return;
          }
        }

        if (!hibpKey) {
          setResult(`### 🛡 HIBP_INTEGRATION_ACTIVE\n\nTo perform real-time account breach checks, please configure your **HIBP_API_KEY** in the system environment.\n\n**Node Status:** Simulation Mode Active.\n\n**Query:** ${searchQuery}\n\n*Simulated Result:* This account appears in 3 known breaches (LinkedIn, Adobe, Canva).`);
          setIsLoading(false);
          return;
        }

        // Real HIBP Account Check
        const response = await fetch(`https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(searchQuery)}?truncateResponse=false`, {
          headers: { 'hibp-api-key': hibpKey, 'user-agent': 'Cyber-Info-Hub' }
        });

        if (response.status === 404) {
          setResult(`### ✅ NO_BREACHES_FOUND\n\nGood news! The account **${searchQuery}** was not found in any known data breaches indexed by Have I Been Pwned.`);
        } else if (response.ok) {
          const breaches = await response.json();
          let report = `### ⚠️ BREACHES_DETECTED (${breaches.length})\n\nThe account **${searchQuery}** has been found in the following data breaches:\n\n`;
          breaches.forEach((b: any) => {
            report += `#### ${b.Title} (${b.BreachDate})\n- **Data Classes:** ${b.DataClasses.join(', ')}\n- **Description:** ${b.Description.replace(/<[^>]*>?/gm, '')}\n\n`;
          });
          setResult(report);
        } else {
          throw new Error(`HIBP API Error: ${response.status}`);
        }
        setIsLoading(false);
        return;
      }

      const systemInstruction = activeNode.id === 'gov' 
        ? `Act as a government services assistant for India. Provide detailed information on how to track applications, download certificates, and check statuses on the ServicePlus portal (serviceonline.gov.in). If the user asks for a specific certificate (like Caste, Income, Birth), provide the direct steps or links if possible. Always mention that the official portal is https://serviceonline.gov.in/userCertificate.html for certificate downloads.`
        : activeNode.id === 'dgft'
        ? `Act as a trade intelligence assistant for DGFT (Directorate General of Foreign Trade, India). Provide detailed information on the Common Digital Platform for Certificate of Origin (COO). Help users with steps for exporter registration, applying for COO, verifying certificates, and tracking application status on https://coo.dgft.gov.in/. Provide technical guidance on the digital signature requirements and document uploads.`
        : `Act as a senior cyber intelligence analyst. Provide a detailed, technical, and actionable intelligence report for the following query within the context of ${activeNode.name}: "${searchQuery}". Include potential threats, mitigation strategies, and relevant technical indicators. Use a professional, "hacker-style" markdown format.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: searchQuery,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });

      const reportText = response.text || 'No intelligence data retrieved for this node.';
      setResult(reportText);
      
      // Add to history
      const historyItem: SearchHistoryItem = {
        id: Math.random().toString(36).substr(2, 9),
        query: searchQuery,
        nodeName: activeNode.name,
        timestamp: Date.now(),
        result: reportText,
      };
      setHistory(prev => [historyItem, ...prev].slice(0, 20));

      // Extract grounding sources
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const extractedSources = chunks
          .filter(chunk => chunk.web)
          .map(chunk => ({
            title: chunk.web?.title || 'Source',
            uri: chunk.web?.uri || ''
          }))
          .filter(source => source.uri !== '');
        setSources(extractedSources);
      }
    } catch (err) {
      console.error('Gemini Error:', err);
      setError('Failed to establish secure connection to the intelligence hub.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-hacker-glass border border-neon/20 p-8 rounded-2xl hover:border-neon transition-all shadow-[0_0_30px_rgba(159,239,0,0.05)]">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-neon/10 rounded-lg">
            <ShieldCheck className="w-8 h-8 text-neon" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-[0.3em] text-white uppercase">CYBER-INFO</h3>
            <p className="text-[10px] text-neon/60 tracking-widest uppercase mt-1">Unified Multi-Node Intelligence Interface</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-black/40 border border-neon/10 rounded-lg p-1 mr-4">
            <button 
              onClick={() => setView('SEARCH')}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${view === 'SEARCH' ? 'bg-neon text-black' : 'text-neon/40 hover:text-neon/60'}`}
            >
              <Search className="w-3 h-3" /> Search
            </button>
            <button 
              onClick={() => setView('HISTORY')}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${view === 'HISTORY' ? 'bg-neon text-black' : 'text-neon/40 hover:text-neon/60'}`}
            >
              <History className="w-3 h-3" /> History
            </button>
            <button 
              onClick={() => setView('PROFILE')}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${view === 'PROFILE' ? 'bg-neon text-black' : 'text-neon/40 hover:text-neon/60'}`}
            >
              <User className="w-3 h-3" /> Profile
            </button>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-neon/5 border border-neon/20 rounded-full">
            <Zap className="w-3 h-3 text-neon animate-pulse" />
            <span className="text-[9px] font-bold text-neon uppercase tracking-tighter">System Status: Active</span>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {view === 'SEARCH' && (
          <motion.div
            key="search-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            {/* Node Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-10">
              {INTELLIGENCE_NODES.map((node) => (
                <motion.button
                  key={node.id}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setActiveNode(node);
                    setResult(null);
                    setQuery('');
                  }}
                  className={`p-4 rounded-xl border transition-all flex flex-col items-center gap-3 text-center group ${
                    activeNode.id === node.id 
                      ? 'bg-neon border-neon text-black shadow-[0_0_20px_rgba(159,239,0,0.3)]' 
                      : 'bg-black/40 border-neon/10 text-neon/60 hover:border-neon/40'
                  }`}
                >
                  <node.icon className={`w-6 h-6 ${activeNode.id === node.id ? 'text-black' : 'text-neon group-hover:scale-110 transition-transform'}`} />
                  <div className="flex flex-col">
                    <span className="text-[9px] font-black tracking-tighter uppercase leading-none">{node.name}</span>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Sub-nodes for Cyber Security */}
            {activeNode.id === 'cyber' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {SECURITY_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-neon/5 rounded hover:border-neon/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-neon/40 group-hover:text-neon transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for HIBP */}
            {activeNode.id === 'hibp' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {HIBP_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-neon/5 rounded hover:border-neon/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-neon/40 group-hover:text-neon transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for Gov Services */}
            {activeNode.id === 'gov' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {GOV_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-neon/5 rounded hover:border-neon/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-neon/40 group-hover:text-neon transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Sub-nodes for DGFT COO */}
            {activeNode.id === 'dgft' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-8"
              >
                {DGFT_SUB_NODES.map((node) => (
                  <button
                    key={node.name}
                    onClick={() => {
                      setQuery(node.name);
                      searchHub(node.name);
                    }}
                    className="p-2 bg-black/20 border border-neon/5 rounded hover:border-neon/30 transition-all text-left group"
                  >
                    <span className="text-[8px] font-bold text-neon/40 group-hover:text-neon transition-colors block truncate">{node.name}</span>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Unified Search */}
            <div className="relative mb-8">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                <activeNode.icon className="w-4 h-4 text-neon/40" />
                <div className="h-4 w-[1px] bg-neon/20" />
              </div>
              <form onSubmit={searchHub}>
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={`QUERY_${activeNode.name}_NODE...`}
                  className="w-full pl-14 pr-14 py-4 bg-black/60 border border-neon/20 text-neon outline-none font-mono placeholder:text-neon/10 focus:border-neon focus:shadow-[0_0_15px_rgba(159,239,0,0.1)] transition-all rounded-xl text-sm"
                />
                <button 
                  type="submit"
                  disabled={isLoading}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-neon text-black hover:shadow-[0_0_15px_rgba(159,239,0,0.5)] transition-all rounded-lg disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                </button>
              </form>
            </div>

            {/* Results Area */}
            <AnimatePresence mode="wait">
              {error && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-4 border border-red-500/30 bg-red-500/5 text-red-500 text-xs font-mono mb-6 rounded-lg"
                >
                  {">"} ERROR: {error}
                </motion.div>
              )}

              {result && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-black/40 border border-neon/10 rounded-2xl p-8 max-h-[600px] overflow-y-auto custom-scrollbar relative"
                >
                  <div className="flex items-center justify-between mb-6 border-b border-neon/10 pb-4">
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5 text-neon" />
                      <span className="text-xs font-bold uppercase tracking-[0.2em] text-white">INTELLIGENCE_REPORT_DECRYPTED</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center bg-neon/5 border border-neon/20 rounded-lg p-0.5">
                        <button
                          onClick={() => setCurrentLang('EN')}
                          className={`px-3 py-1 text-[10px] font-bold rounded transition-all ${currentLang === 'EN' ? 'bg-neon text-black' : 'text-neon/40 hover:text-neon/60'}`}
                        >
                          EN
                        </button>
                        <button
                          onClick={() => translateResult('HI')}
                          disabled={isTranslating}
                          className={`px-3 py-1 text-[10px] font-bold rounded transition-all flex items-center gap-2 ${currentLang === 'HI' ? 'bg-neon text-black' : 'text-neon/40 hover:text-neon/60'}`}
                        >
                          {isTranslating ? <Loader2 className="w-3 h-3 animate-spin" /> : 'HI'}
                        </button>
                      </div>
                      <button
                        onClick={downloadPDF}
                        className="flex items-center gap-2 text-[10px] uppercase font-bold px-3 py-1.5 rounded-lg border border-neon/20 text-neon hover:bg-neon/10 transition-all"
                      >
                        <Download className="w-3 h-3" /> PDF
                      </button>
                      <button
                        onClick={sendToTelegram}
                        disabled={isSending || !result}
                        className={`flex items-center gap-2 text-[10px] uppercase font-bold px-3 py-1.5 rounded-lg border transition-all ${
                          sendSuccess 
                            ? 'bg-neon border-neon text-black' 
                            : 'bg-neon/5 border-neon/20 text-neon hover:bg-neon/10'
                        }`}
                      >
                        {isSending ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : sendSuccess ? (
                          <>SENT <ShieldCheck className="w-3 h-3" /></>
                        ) : (
                          <>SEND_TO_TELEGRAM <Send className="w-3 h-3" /></>
                        )}
                      </button>
                      <a 
                        href={activeNode.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-[10px] text-neon/40 hover:text-neon transition-colors uppercase font-bold"
                      >
                        Source Portal <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                  <div className="markdown-body text-white/80 text-sm font-mono leading-relaxed space-y-4">
                    <Markdown>{currentLang === 'HI' ? translatedResult : result}</Markdown>
                  </div>

                  {sources.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-neon/10">
                      <div className="flex items-center gap-2 mb-4">
                        <BookOpen className="w-4 h-4 text-neon/60" />
                        <span className="text-[10px] font-bold text-neon/60 uppercase tracking-widest">Intelligence Sources</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {sources.map((source, idx) => (
                          <a
                            key={idx}
                            href={source.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-3 bg-neon/5 border border-neon/10 rounded-lg hover:border-neon/30 transition-all flex items-center justify-between group"
                          >
                            <div className="flex flex-col gap-1 overflow-hidden">
                              <span className="text-[10px] font-bold text-white/80 truncate">{source.title}</span>
                              <span className="text-[8px] text-neon/40 truncate">{source.uri}</span>
                            </div>
                            <ExternalLink className="w-3 h-3 text-neon/20 group-hover:text-neon transition-colors flex-shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {!result && !isLoading && !error && (
              <div className="flex flex-col items-center justify-center py-20 text-white/5 font-mono text-xs gap-6 border border-dashed border-neon/5 rounded-2xl mt-8">
                <div className="relative">
                  <Lock className="w-12 h-12 opacity-10" />
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border border-dashed border-neon/20 rounded-full scale-150"
                  />
                </div>
                <div className="flex flex-col items-center gap-2">
                  <span className="tracking-[0.5em] uppercase">Awaiting Encrypted Query</span>
                  <span className="text-[8px] opacity-50">Select a node and enter parameters to begin retrieval</span>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {view === 'HISTORY' && (
          <motion.div
            key="history-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <History className="w-5 h-5 text-neon" />
                <h4 className="text-sm font-bold uppercase tracking-widest text-white">Intelligence Retrieval History</h4>
              </div>
              <button 
                onClick={() => setHistory([])}
                className="text-[10px] text-red-500/60 hover:text-red-500 flex items-center gap-2 uppercase font-bold transition-colors"
              >
                <Trash2 className="w-3 h-3" /> Clear History
              </button>
            </div>

            {history.length === 0 ? (
              <div className="py-20 text-center border border-dashed border-neon/10 rounded-xl">
                <Clock className="w-8 h-8 text-neon/10 mx-auto mb-4" />
                <p className="text-[10px] text-neon/20 uppercase tracking-widest">No retrieval logs found in current session</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {history.map((item) => (
                  <div 
                    key={item.id}
                    className="p-4 bg-black/40 border border-neon/10 rounded-xl hover:border-neon/30 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="px-2 py-0.5 bg-neon/10 border border-neon/20 rounded text-[8px] font-bold text-neon uppercase">
                          {item.nodeName}
                        </div>
                        <span className="text-xs font-bold text-white/80">{item.query}</span>
                      </div>
                      <span className="text-[8px] text-neon/30">{new Date(item.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <button 
                      onClick={() => {
                        setResult(item.result);
                        setView('SEARCH');
                      }}
                      className="text-[9px] text-neon/60 hover:text-neon uppercase font-bold flex items-center gap-2 transition-colors"
                    >
                      Restore Report
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {view === 'PROFILE' && (
          <motion.div
            key="profile-view"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-black/40 border border-neon/10 rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <User className="w-32 h-32" />
              </div>
              
              <div className="flex items-center gap-6 mb-8 relative z-10">
                <div className="w-20 h-20 rounded-2xl bg-neon/10 border border-neon/30 flex items-center justify-center">
                  <User className="w-10 h-10 text-neon" />
                </div>
                <div>
                  <h4 className="text-2xl font-bold text-white tracking-tighter uppercase">
                    {(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.first_name || 'ANONYMOUS_OPERATOR'}
                  </h4>
                  <p className="text-xs text-neon/60 font-mono">
                    ID: {(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id || '0x' + Math.random().toString(16).substr(2, 8).toUpperCase()}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
                <div className="p-4 bg-neon/5 border border-neon/10 rounded-xl">
                  <span className="text-[10px] text-neon/40 uppercase font-bold block mb-1">Access Level</span>
                  <span className="text-sm text-neon font-mono">LEVEL_4_ADMIN</span>
                </div>
                <div className="p-4 bg-neon/5 border border-neon/10 rounded-xl">
                  <span className="text-[10px] text-neon/40 uppercase font-bold block mb-1">Session Status</span>
                  <span className="text-sm text-green-400 font-mono">ENCRYPTED_ACTIVE</span>
                </div>
                <div className="p-4 bg-neon/5 border border-neon/10 rounded-xl">
                  <span className="text-[10px] text-neon/40 uppercase font-bold block mb-1">Total Retrievals</span>
                  <span className="text-sm text-white font-mono">{history.length}</span>
                </div>
                <div className="p-4 bg-neon/5 border border-neon/10 rounded-xl">
                  <span className="text-[10px] text-neon/40 uppercase font-bold block mb-1">Node Connection</span>
                  <span className="text-sm text-white font-mono">STABLE</span>
                </div>
              </div>

              {(window as any).Telegram?.WebApp?.initDataUnsafe?.user && (
                <div className="mt-8 p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl flex items-center gap-4">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Send className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-blue-400/60 uppercase font-bold block">Telegram Linked</span>
                    <span className="text-xs text-blue-400 font-mono">@{(window as any).Telegram?.WebApp?.initDataUnsafe?.user?.username || 'N/A'}</span>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
