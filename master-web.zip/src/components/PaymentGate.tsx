import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  CreditCard, 
  ShieldCheck, 
  AlertCircle, 
  ArrowRight,
  ExternalLink,
  Smartphone,
  CheckCircle2,
  Loader2
} from 'lucide-react';

interface PaymentGateProps {
  onPaymentSuccess: () => void;
  upiId: string;
}

export const PaymentGate: React.FC<PaymentGateProps> = ({ onPaymentSuccess, upiId }) => {
  const [amount, setAmount] = useState<string>('299');
  const [isVerifying, setIsVerifying] = useState(false);
  const [status, setStatus] = useState<'IDLE' | 'PENDING' | 'SUCCESS'>('IDLE');

  const upiUrl = `upi://pay?pa=${upiId}&pn=Master%20Web&am=${amount}&cu=INR&tn=Access%20Master%20Web%20Support`;

  const startAutomatedCheck = () => {
    if (!amount || parseFloat(amount) <= 0) return;
    setStatus('PENDING');
    setIsVerifying(true);
    
    // Simulate automated payment detection
    setTimeout(() => {
      setStatus('SUCCESS');
      setIsVerifying(false);
      setTimeout(() => {
        onPaymentSuccess();
      }, 1500);
    }, 4000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-hacker-bg/98 p-4"
    >
      <div className="w-full max-w-md p-8 border rounded-2xl bg-hacker-glass border-neon shadow-[0_0_30px_rgba(159,239,0,0.2)] text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-neon/20 animate-pulse" />
        
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-neon/10 rounded-full border border-neon/30">
            <CreditCard className="w-10 h-10 text-neon" />
          </div>
        </div>

        <h2 className="text-2xl font-bold mb-2 tracking-tighter text-white uppercase">
          {">"} SUPPORT_ACCESS_REQUIRED
        </h2>
        <p className="text-[10px] mb-8 text-neon/70 uppercase tracking-widest">
          Secure Transaction Node: Active
        </p>

        {/* Custom Amount Input */}
        <div className="mb-8">
          <label className="text-[10px] text-neon/40 uppercase font-bold block mb-2 text-left">ENTER_SUPPORT_AMOUNT (INR)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neon font-mono">₹</span>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-10 pr-4 py-4 bg-black/60 border border-neon/20 text-neon outline-none font-mono placeholder:text-neon/10 focus:border-neon focus:shadow-[0_0_15px_rgba(159,239,0,0.1)] transition-all rounded-xl text-lg"
            />
          </div>
          <p className="text-[8px] text-neon/30 mt-2 uppercase tracking-tighter text-left">Your support helps maintain the intelligence infrastructure</p>
        </div>

        <div className="bg-black/40 border border-neon/10 rounded-xl p-6 mb-8 flex flex-col items-center gap-4">
          <div className="p-3 bg-white rounded-lg shadow-[0_0_15px_rgba(255,255,255,0.1)]">
            <QRCodeSVG value={upiUrl} size={140} />
          </div>
          
          <div className="text-center">
            <span className="text-[10px] text-neon/40 uppercase font-bold block mb-1">UPI_ID_IDENTIFIED</span>
            <code className="text-sm text-neon font-mono bg-neon/5 px-3 py-1 rounded border border-neon/20">
              {upiId}
            </code>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 mb-8">
          <a 
            href={upiUrl}
            onClick={startAutomatedCheck}
            className="flex items-center justify-center gap-3 py-3 bg-neon text-black font-bold uppercase tracking-widest rounded-lg hover:shadow-[0_0_20px_rgba(159,239,0,0.5)] transition-all group"
          >
            <Smartphone className="w-4 h-4" />
            PAY_₹{amount || '0'}_VIA_APP
            <ExternalLink className="w-3 h-3 opacity-50 group-hover:opacity-100" />
          </a>
        </div>

        <AnimatePresence mode="wait">
          {status === 'PENDING' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-center gap-3 p-4 bg-neon/5 border border-neon/20 rounded-lg mb-4"
            >
              <Loader2 className="w-4 h-4 text-neon animate-spin" />
              <span className="text-[10px] text-neon font-bold uppercase tracking-widest">Awaiting_Payment_Confirmation...</span>
            </motion.div>
          )}
          {status === 'SUCCESS' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-center gap-3 p-4 bg-green-500/10 border border-green-500/30 rounded-lg mb-4"
            >
              <CheckCircle2 className="w-4 h-4 text-green-400" />
              <span className="text-[10px] text-green-400 font-bold uppercase tracking-widest">Payment_Verified_Access_Granted</span>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-start gap-3 p-4 bg-neon/5 border border-neon/10 rounded-lg text-left">
          <AlertCircle className="w-5 h-5 text-neon/60 flex-shrink-0 mt-0.5" />
          <p className="text-[9px] text-neon/60 leading-relaxed uppercase tracking-wider">
            Enter your support amount and complete the transaction. 
            The system will automatically unlock your terminal upon successful payment detection.
          </p>
        </div>
      </div>
    </motion.div>
  );
};
